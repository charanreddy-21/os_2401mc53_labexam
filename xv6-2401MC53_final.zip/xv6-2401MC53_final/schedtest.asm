
_schedtest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	56                   	push   %esi
   e:	53                   	push   %ebx
   f:	51                   	push   %ecx
  10:	83 ec 1c             	sub    $0x1c,%esp
  13:	c7 45 dc 05 00 00 00 	movl   $0x5,-0x24(%ebp)
  1a:	c7 45 e0 0a 00 00 00 	movl   $0xa,-0x20(%ebp)
  21:	c7 45 e4 0f 00 00 00 	movl   $0xf,-0x1c(%ebp)
  28:	e8 f2 02 00 00       	call   31f <getpid>
  2d:	83 ec 08             	sub    $0x8,%esp
  30:	6a 01                	push   $0x1
  32:	50                   	push   %eax
  33:	e8 17 03 00 00       	call   34f <set_priority>
  38:	8d 5d dc             	lea    -0x24(%ebp),%ebx
  3b:	8d 75 e8             	lea    -0x18(%ebp),%esi
  3e:	83 c4 10             	add    $0x10,%esp
  41:	e8 51 02 00 00       	call   297 <fork>
  46:	85 c0                	test   %eax,%eax
  48:	78 3f                	js     89 <main+0x89>
  4a:	8b 13                	mov    (%ebx),%edx
  4c:	74 4e                	je     9c <main+0x9c>
  4e:	83 ec 08             	sub    $0x8,%esp
  51:	52                   	push   %edx
  52:	50                   	push   %eax
  53:	e8 f7 02 00 00       	call   34f <set_priority>
  58:	83 c4 10             	add    $0x10,%esp
  5b:	85 c0                	test   %eax,%eax
  5d:	78 68                	js     c7 <main+0xc7>
  5f:	83 c3 04             	add    $0x4,%ebx
  62:	39 de                	cmp    %ebx,%esi
  64:	75 db                	jne    41 <main+0x41>
  66:	e8 3c 02 00 00       	call   2a7 <wait>
  6b:	e8 37 02 00 00       	call   2a7 <wait>
  70:	e8 32 02 00 00       	call   2a7 <wait>
  75:	83 ec 08             	sub    $0x8,%esp
  78:	68 f6 06 00 00       	push   $0x6f6
  7d:	6a 01                	push   $0x1
  7f:	e8 60 03 00 00       	call   3e4 <printf>
  84:	e8 16 02 00 00       	call   29f <exit>
  89:	56                   	push   %esi
  8a:	56                   	push   %esi
  8b:	68 c8 06 00 00       	push   $0x6c8
  90:	6a 01                	push   $0x1
  92:	e8 4d 03 00 00       	call   3e4 <printf>
  97:	e8 03 02 00 00       	call   29f <exit>
  9c:	31 db                	xor    %ebx,%ebx
  9e:	89 5d d8             	mov    %ebx,-0x28(%ebp)
  a1:	eb 07                	jmp    aa <main+0xaa>
  a3:	8b 45 d8             	mov    -0x28(%ebp),%eax
  a6:	40                   	inc    %eax
  a7:	89 45 d8             	mov    %eax,-0x28(%ebp)
  aa:	8b 45 d8             	mov    -0x28(%ebp),%eax
  ad:	3d 7f f0 fa 02       	cmp    $0x2faf07f,%eax
  b2:	76 ef                	jbe    a3 <main+0xa3>
  b4:	51                   	push   %ecx
  b5:	52                   	push   %edx
  b6:	68 e0 06 00 00       	push   $0x6e0
  bb:	6a 01                	push   $0x1
  bd:	e8 22 03 00 00       	call   3e4 <printf>
  c2:	e8 d8 01 00 00       	call   29f <exit>
  c7:	50                   	push   %eax
  c8:	50                   	push   %eax
  c9:	68 fc 06 00 00       	push   $0x6fc
  ce:	6a 01                	push   $0x1
  d0:	e8 0f 03 00 00       	call   3e4 <printf>
  d5:	e8 c5 01 00 00       	call   29f <exit>
  da:	66 90                	xchg   %ax,%ax

000000dc <strcpy>:
  dc:	55                   	push   %ebp
  dd:	89 e5                	mov    %esp,%ebp
  df:	53                   	push   %ebx
  e0:	8b 4d 08             	mov    0x8(%ebp),%ecx
  e3:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  e6:	31 c0                	xor    %eax,%eax
  e8:	8a 14 03             	mov    (%ebx,%eax,1),%dl
  eb:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  ee:	40                   	inc    %eax
  ef:	84 d2                	test   %dl,%dl
  f1:	75 f5                	jne    e8 <strcpy+0xc>
  f3:	89 c8                	mov    %ecx,%eax
  f5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  f8:	c9                   	leave  
  f9:	c3                   	ret    
  fa:	66 90                	xchg   %ax,%ax

000000fc <strcmp>:
  fc:	55                   	push   %ebp
  fd:	89 e5                	mov    %esp,%ebp
  ff:	53                   	push   %ebx
 100:	8b 55 08             	mov    0x8(%ebp),%edx
 103:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 106:	0f b6 02             	movzbl (%edx),%eax
 109:	84 c0                	test   %al,%al
 10b:	75 10                	jne    11d <strcmp+0x21>
 10d:	eb 2a                	jmp    139 <strcmp+0x3d>
 10f:	90                   	nop
 110:	42                   	inc    %edx
 111:	8d 4b 01             	lea    0x1(%ebx),%ecx
 114:	0f b6 02             	movzbl (%edx),%eax
 117:	84 c0                	test   %al,%al
 119:	74 11                	je     12c <strcmp+0x30>
 11b:	89 cb                	mov    %ecx,%ebx
 11d:	0f b6 0b             	movzbl (%ebx),%ecx
 120:	38 c1                	cmp    %al,%cl
 122:	74 ec                	je     110 <strcmp+0x14>
 124:	29 c8                	sub    %ecx,%eax
 126:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 129:	c9                   	leave  
 12a:	c3                   	ret    
 12b:	90                   	nop
 12c:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
 130:	31 c0                	xor    %eax,%eax
 132:	29 c8                	sub    %ecx,%eax
 134:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 137:	c9                   	leave  
 138:	c3                   	ret    
 139:	0f b6 0b             	movzbl (%ebx),%ecx
 13c:	31 c0                	xor    %eax,%eax
 13e:	eb e4                	jmp    124 <strcmp+0x28>

00000140 <strlen>:
 140:	55                   	push   %ebp
 141:	89 e5                	mov    %esp,%ebp
 143:	8b 55 08             	mov    0x8(%ebp),%edx
 146:	80 3a 00             	cmpb   $0x0,(%edx)
 149:	74 15                	je     160 <strlen+0x20>
 14b:	31 c0                	xor    %eax,%eax
 14d:	8d 76 00             	lea    0x0(%esi),%esi
 150:	40                   	inc    %eax
 151:	89 c1                	mov    %eax,%ecx
 153:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 157:	75 f7                	jne    150 <strlen+0x10>
 159:	89 c8                	mov    %ecx,%eax
 15b:	5d                   	pop    %ebp
 15c:	c3                   	ret    
 15d:	8d 76 00             	lea    0x0(%esi),%esi
 160:	31 c9                	xor    %ecx,%ecx
 162:	89 c8                	mov    %ecx,%eax
 164:	5d                   	pop    %ebp
 165:	c3                   	ret    
 166:	66 90                	xchg   %ax,%ax

00000168 <memset>:
 168:	55                   	push   %ebp
 169:	89 e5                	mov    %esp,%ebp
 16b:	57                   	push   %edi
 16c:	8b 7d 08             	mov    0x8(%ebp),%edi
 16f:	8b 4d 10             	mov    0x10(%ebp),%ecx
 172:	8b 45 0c             	mov    0xc(%ebp),%eax
 175:	fc                   	cld    
 176:	f3 aa                	rep stos %al,%es:(%edi)
 178:	8b 45 08             	mov    0x8(%ebp),%eax
 17b:	8b 7d fc             	mov    -0x4(%ebp),%edi
 17e:	c9                   	leave  
 17f:	c3                   	ret    

00000180 <strchr>:
 180:	55                   	push   %ebp
 181:	89 e5                	mov    %esp,%ebp
 183:	8b 45 08             	mov    0x8(%ebp),%eax
 186:	8a 4d 0c             	mov    0xc(%ebp),%cl
 189:	8a 10                	mov    (%eax),%dl
 18b:	84 d2                	test   %dl,%dl
 18d:	75 0c                	jne    19b <strchr+0x1b>
 18f:	eb 13                	jmp    1a4 <strchr+0x24>
 191:	8d 76 00             	lea    0x0(%esi),%esi
 194:	40                   	inc    %eax
 195:	8a 10                	mov    (%eax),%dl
 197:	84 d2                	test   %dl,%dl
 199:	74 09                	je     1a4 <strchr+0x24>
 19b:	38 d1                	cmp    %dl,%cl
 19d:	75 f5                	jne    194 <strchr+0x14>
 19f:	5d                   	pop    %ebp
 1a0:	c3                   	ret    
 1a1:	8d 76 00             	lea    0x0(%esi),%esi
 1a4:	31 c0                	xor    %eax,%eax
 1a6:	5d                   	pop    %ebp
 1a7:	c3                   	ret    

000001a8 <gets>:
 1a8:	55                   	push   %ebp
 1a9:	89 e5                	mov    %esp,%ebp
 1ab:	57                   	push   %edi
 1ac:	56                   	push   %esi
 1ad:	53                   	push   %ebx
 1ae:	83 ec 1c             	sub    $0x1c,%esp
 1b1:	31 db                	xor    %ebx,%ebx
 1b3:	8d 75 e7             	lea    -0x19(%ebp),%esi
 1b6:	eb 24                	jmp    1dc <gets+0x34>
 1b8:	50                   	push   %eax
 1b9:	6a 01                	push   $0x1
 1bb:	56                   	push   %esi
 1bc:	6a 00                	push   $0x0
 1be:	e8 f4 00 00 00       	call   2b7 <read>
 1c3:	83 c4 10             	add    $0x10,%esp
 1c6:	85 c0                	test   %eax,%eax
 1c8:	7e 1a                	jle    1e4 <gets+0x3c>
 1ca:	8a 45 e7             	mov    -0x19(%ebp),%al
 1cd:	8b 55 08             	mov    0x8(%ebp),%edx
 1d0:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 1d4:	3c 0a                	cmp    $0xa,%al
 1d6:	74 0e                	je     1e6 <gets+0x3e>
 1d8:	3c 0d                	cmp    $0xd,%al
 1da:	74 0a                	je     1e6 <gets+0x3e>
 1dc:	89 df                	mov    %ebx,%edi
 1de:	43                   	inc    %ebx
 1df:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1e2:	7c d4                	jl     1b8 <gets+0x10>
 1e4:	89 fb                	mov    %edi,%ebx
 1e6:	8b 45 08             	mov    0x8(%ebp),%eax
 1e9:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 1ed:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1f0:	5b                   	pop    %ebx
 1f1:	5e                   	pop    %esi
 1f2:	5f                   	pop    %edi
 1f3:	5d                   	pop    %ebp
 1f4:	c3                   	ret    
 1f5:	8d 76 00             	lea    0x0(%esi),%esi

000001f8 <stat>:
 1f8:	55                   	push   %ebp
 1f9:	89 e5                	mov    %esp,%ebp
 1fb:	56                   	push   %esi
 1fc:	53                   	push   %ebx
 1fd:	83 ec 08             	sub    $0x8,%esp
 200:	6a 00                	push   $0x0
 202:	ff 75 08             	pushl  0x8(%ebp)
 205:	e8 d5 00 00 00       	call   2df <open>
 20a:	83 c4 10             	add    $0x10,%esp
 20d:	85 c0                	test   %eax,%eax
 20f:	78 27                	js     238 <stat+0x40>
 211:	89 c3                	mov    %eax,%ebx
 213:	83 ec 08             	sub    $0x8,%esp
 216:	ff 75 0c             	pushl  0xc(%ebp)
 219:	50                   	push   %eax
 21a:	e8 d8 00 00 00       	call   2f7 <fstat>
 21f:	89 c6                	mov    %eax,%esi
 221:	89 1c 24             	mov    %ebx,(%esp)
 224:	e8 9e 00 00 00       	call   2c7 <close>
 229:	83 c4 10             	add    $0x10,%esp
 22c:	89 f0                	mov    %esi,%eax
 22e:	8d 65 f8             	lea    -0x8(%ebp),%esp
 231:	5b                   	pop    %ebx
 232:	5e                   	pop    %esi
 233:	5d                   	pop    %ebp
 234:	c3                   	ret    
 235:	8d 76 00             	lea    0x0(%esi),%esi
 238:	be ff ff ff ff       	mov    $0xffffffff,%esi
 23d:	eb ed                	jmp    22c <stat+0x34>
 23f:	90                   	nop

00000240 <atoi>:
 240:	55                   	push   %ebp
 241:	89 e5                	mov    %esp,%ebp
 243:	53                   	push   %ebx
 244:	8b 4d 08             	mov    0x8(%ebp),%ecx
 247:	0f be 01             	movsbl (%ecx),%eax
 24a:	8d 50 d0             	lea    -0x30(%eax),%edx
 24d:	80 fa 09             	cmp    $0x9,%dl
 250:	ba 00 00 00 00       	mov    $0x0,%edx
 255:	77 16                	ja     26d <atoi+0x2d>
 257:	90                   	nop
 258:	41                   	inc    %ecx
 259:	8d 14 92             	lea    (%edx,%edx,4),%edx
 25c:	01 d2                	add    %edx,%edx
 25e:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 262:	0f be 01             	movsbl (%ecx),%eax
 265:	8d 58 d0             	lea    -0x30(%eax),%ebx
 268:	80 fb 09             	cmp    $0x9,%bl
 26b:	76 eb                	jbe    258 <atoi+0x18>
 26d:	89 d0                	mov    %edx,%eax
 26f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 272:	c9                   	leave  
 273:	c3                   	ret    

00000274 <memmove>:
 274:	55                   	push   %ebp
 275:	89 e5                	mov    %esp,%ebp
 277:	57                   	push   %edi
 278:	56                   	push   %esi
 279:	8b 55 08             	mov    0x8(%ebp),%edx
 27c:	8b 75 0c             	mov    0xc(%ebp),%esi
 27f:	8b 45 10             	mov    0x10(%ebp),%eax
 282:	85 c0                	test   %eax,%eax
 284:	7e 0b                	jle    291 <memmove+0x1d>
 286:	01 d0                	add    %edx,%eax
 288:	89 d7                	mov    %edx,%edi
 28a:	66 90                	xchg   %ax,%ax
 28c:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 28d:	39 f8                	cmp    %edi,%eax
 28f:	75 fb                	jne    28c <memmove+0x18>
 291:	89 d0                	mov    %edx,%eax
 293:	5e                   	pop    %esi
 294:	5f                   	pop    %edi
 295:	5d                   	pop    %ebp
 296:	c3                   	ret    

00000297 <fork>:
 297:	b8 01 00 00 00       	mov    $0x1,%eax
 29c:	cd 40                	int    $0x40
 29e:	c3                   	ret    

0000029f <exit>:
 29f:	b8 02 00 00 00       	mov    $0x2,%eax
 2a4:	cd 40                	int    $0x40
 2a6:	c3                   	ret    

000002a7 <wait>:
 2a7:	b8 03 00 00 00       	mov    $0x3,%eax
 2ac:	cd 40                	int    $0x40
 2ae:	c3                   	ret    

000002af <pipe>:
 2af:	b8 04 00 00 00       	mov    $0x4,%eax
 2b4:	cd 40                	int    $0x40
 2b6:	c3                   	ret    

000002b7 <read>:
 2b7:	b8 05 00 00 00       	mov    $0x5,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <write>:
 2bf:	b8 10 00 00 00       	mov    $0x10,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <close>:
 2c7:	b8 15 00 00 00       	mov    $0x15,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <kill>:
 2cf:	b8 06 00 00 00       	mov    $0x6,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <exec>:
 2d7:	b8 07 00 00 00       	mov    $0x7,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret    

000002df <open>:
 2df:	b8 0f 00 00 00       	mov    $0xf,%eax
 2e4:	cd 40                	int    $0x40
 2e6:	c3                   	ret    

000002e7 <mknod>:
 2e7:	b8 11 00 00 00       	mov    $0x11,%eax
 2ec:	cd 40                	int    $0x40
 2ee:	c3                   	ret    

000002ef <unlink>:
 2ef:	b8 12 00 00 00       	mov    $0x12,%eax
 2f4:	cd 40                	int    $0x40
 2f6:	c3                   	ret    

000002f7 <fstat>:
 2f7:	b8 08 00 00 00       	mov    $0x8,%eax
 2fc:	cd 40                	int    $0x40
 2fe:	c3                   	ret    

000002ff <link>:
 2ff:	b8 13 00 00 00       	mov    $0x13,%eax
 304:	cd 40                	int    $0x40
 306:	c3                   	ret    

00000307 <mkdir>:
 307:	b8 14 00 00 00       	mov    $0x14,%eax
 30c:	cd 40                	int    $0x40
 30e:	c3                   	ret    

0000030f <chdir>:
 30f:	b8 09 00 00 00       	mov    $0x9,%eax
 314:	cd 40                	int    $0x40
 316:	c3                   	ret    

00000317 <dup>:
 317:	b8 0a 00 00 00       	mov    $0xa,%eax
 31c:	cd 40                	int    $0x40
 31e:	c3                   	ret    

0000031f <getpid>:
 31f:	b8 0b 00 00 00       	mov    $0xb,%eax
 324:	cd 40                	int    $0x40
 326:	c3                   	ret    

00000327 <sbrk>:
 327:	b8 0c 00 00 00       	mov    $0xc,%eax
 32c:	cd 40                	int    $0x40
 32e:	c3                   	ret    

0000032f <sleep>:
 32f:	b8 0d 00 00 00       	mov    $0xd,%eax
 334:	cd 40                	int    $0x40
 336:	c3                   	ret    

00000337 <uptime>:
 337:	b8 0e 00 00 00       	mov    $0xe,%eax
 33c:	cd 40                	int    $0x40
 33e:	c3                   	ret    

0000033f <mprotect>:
 33f:	b8 16 00 00 00       	mov    $0x16,%eax
 344:	cd 40                	int    $0x40
 346:	c3                   	ret    

00000347 <munprotect>:
 347:	b8 17 00 00 00       	mov    $0x17,%eax
 34c:	cd 40                	int    $0x40
 34e:	c3                   	ret    

0000034f <set_priority>:
 34f:	b8 18 00 00 00       	mov    $0x18,%eax
 354:	cd 40                	int    $0x40
 356:	c3                   	ret    
 357:	90                   	nop

00000358 <printint>:
 358:	55                   	push   %ebp
 359:	89 e5                	mov    %esp,%ebp
 35b:	57                   	push   %edi
 35c:	56                   	push   %esi
 35d:	53                   	push   %ebx
 35e:	83 ec 3c             	sub    $0x3c,%esp
 361:	89 45 c0             	mov    %eax,-0x40(%ebp)
 364:	89 cb                	mov    %ecx,%ebx
 366:	8b 4d 08             	mov    0x8(%ebp),%ecx
 369:	85 c9                	test   %ecx,%ecx
 36b:	74 04                	je     371 <printint+0x19>
 36d:	85 d2                	test   %edx,%edx
 36f:	78 6b                	js     3dc <printint+0x84>
 371:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 374:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 37b:	31 c9                	xor    %ecx,%ecx
 37d:	8d 75 d7             	lea    -0x29(%ebp),%esi
 380:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 383:	31 d2                	xor    %edx,%edx
 385:	f7 f3                	div    %ebx
 387:	89 cf                	mov    %ecx,%edi
 389:	8d 49 01             	lea    0x1(%ecx),%ecx
 38c:	8a 92 7c 07 00 00    	mov    0x77c(%edx),%dl
 392:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 396:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 399:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 39c:	39 da                	cmp    %ebx,%edx
 39e:	73 e0                	jae    380 <printint+0x28>
 3a0:	8b 55 08             	mov    0x8(%ebp),%edx
 3a3:	85 d2                	test   %edx,%edx
 3a5:	74 07                	je     3ae <printint+0x56>
 3a7:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 3ac:	89 cf                	mov    %ecx,%edi
 3ae:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 3b1:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 3b5:	8d 76 00             	lea    0x0(%esi),%esi
 3b8:	8a 07                	mov    (%edi),%al
 3ba:	88 45 d7             	mov    %al,-0x29(%ebp)
 3bd:	50                   	push   %eax
 3be:	6a 01                	push   $0x1
 3c0:	56                   	push   %esi
 3c1:	ff 75 c0             	pushl  -0x40(%ebp)
 3c4:	e8 f6 fe ff ff       	call   2bf <write>
 3c9:	89 f8                	mov    %edi,%eax
 3cb:	4f                   	dec    %edi
 3cc:	83 c4 10             	add    $0x10,%esp
 3cf:	39 d8                	cmp    %ebx,%eax
 3d1:	75 e5                	jne    3b8 <printint+0x60>
 3d3:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3d6:	5b                   	pop    %ebx
 3d7:	5e                   	pop    %esi
 3d8:	5f                   	pop    %edi
 3d9:	5d                   	pop    %ebp
 3da:	c3                   	ret    
 3db:	90                   	nop
 3dc:	f7 da                	neg    %edx
 3de:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 3e1:	eb 98                	jmp    37b <printint+0x23>
 3e3:	90                   	nop

000003e4 <printf>:
 3e4:	55                   	push   %ebp
 3e5:	89 e5                	mov    %esp,%ebp
 3e7:	57                   	push   %edi
 3e8:	56                   	push   %esi
 3e9:	53                   	push   %ebx
 3ea:	83 ec 2c             	sub    $0x2c,%esp
 3ed:	8b 75 08             	mov    0x8(%ebp),%esi
 3f0:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 3f3:	8a 13                	mov    (%ebx),%dl
 3f5:	84 d2                	test   %dl,%dl
 3f7:	74 5c                	je     455 <printf+0x71>
 3f9:	43                   	inc    %ebx
 3fa:	8d 45 10             	lea    0x10(%ebp),%eax
 3fd:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 400:	31 ff                	xor    %edi,%edi
 402:	eb 20                	jmp    424 <printf+0x40>
 404:	83 f8 25             	cmp    $0x25,%eax
 407:	74 3f                	je     448 <printf+0x64>
 409:	88 55 e7             	mov    %dl,-0x19(%ebp)
 40c:	50                   	push   %eax
 40d:	6a 01                	push   $0x1
 40f:	8d 45 e7             	lea    -0x19(%ebp),%eax
 412:	50                   	push   %eax
 413:	56                   	push   %esi
 414:	e8 a6 fe ff ff       	call   2bf <write>
 419:	83 c4 10             	add    $0x10,%esp
 41c:	43                   	inc    %ebx
 41d:	8a 53 ff             	mov    -0x1(%ebx),%dl
 420:	84 d2                	test   %dl,%dl
 422:	74 31                	je     455 <printf+0x71>
 424:	0f b6 c2             	movzbl %dl,%eax
 427:	85 ff                	test   %edi,%edi
 429:	74 d9                	je     404 <printf+0x20>
 42b:	83 ff 25             	cmp    $0x25,%edi
 42e:	75 ec                	jne    41c <printf+0x38>
 430:	83 f8 25             	cmp    $0x25,%eax
 433:	0f 84 03 01 00 00    	je     53c <printf+0x158>
 439:	83 e8 63             	sub    $0x63,%eax
 43c:	83 f8 15             	cmp    $0x15,%eax
 43f:	77 1f                	ja     460 <printf+0x7c>
 441:	ff 24 85 24 07 00 00 	jmp    *0x724(,%eax,4)
 448:	bf 25 00 00 00       	mov    $0x25,%edi
 44d:	43                   	inc    %ebx
 44e:	8a 53 ff             	mov    -0x1(%ebx),%dl
 451:	84 d2                	test   %dl,%dl
 453:	75 cf                	jne    424 <printf+0x40>
 455:	8d 65 f4             	lea    -0xc(%ebp),%esp
 458:	5b                   	pop    %ebx
 459:	5e                   	pop    %esi
 45a:	5f                   	pop    %edi
 45b:	5d                   	pop    %ebp
 45c:	c3                   	ret    
 45d:	8d 76 00             	lea    0x0(%esi),%esi
 460:	88 55 d0             	mov    %dl,-0x30(%ebp)
 463:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 467:	50                   	push   %eax
 468:	6a 01                	push   $0x1
 46a:	8d 7d e7             	lea    -0x19(%ebp),%edi
 46d:	57                   	push   %edi
 46e:	56                   	push   %esi
 46f:	e8 4b fe ff ff       	call   2bf <write>
 474:	8a 55 d0             	mov    -0x30(%ebp),%dl
 477:	88 55 e7             	mov    %dl,-0x19(%ebp)
 47a:	83 c4 0c             	add    $0xc,%esp
 47d:	6a 01                	push   $0x1
 47f:	57                   	push   %edi
 480:	56                   	push   %esi
 481:	e8 39 fe ff ff       	call   2bf <write>
 486:	83 c4 10             	add    $0x10,%esp
 489:	31 ff                	xor    %edi,%edi
 48b:	eb 8f                	jmp    41c <printf+0x38>
 48d:	8d 76 00             	lea    0x0(%esi),%esi
 490:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 493:	8b 17                	mov    (%edi),%edx
 495:	83 ec 0c             	sub    $0xc,%esp
 498:	6a 00                	push   $0x0
 49a:	b9 10 00 00 00       	mov    $0x10,%ecx
 49f:	89 f0                	mov    %esi,%eax
 4a1:	e8 b2 fe ff ff       	call   358 <printint>
 4a6:	83 c7 04             	add    $0x4,%edi
 4a9:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4ac:	83 c4 10             	add    $0x10,%esp
 4af:	31 ff                	xor    %edi,%edi
 4b1:	e9 66 ff ff ff       	jmp    41c <printf+0x38>
 4b6:	66 90                	xchg   %ax,%ax
 4b8:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 4bb:	8b 10                	mov    (%eax),%edx
 4bd:	83 c0 04             	add    $0x4,%eax
 4c0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4c3:	85 d2                	test   %edx,%edx
 4c5:	0f 84 81 00 00 00    	je     54c <printf+0x168>
 4cb:	8a 02                	mov    (%edx),%al
 4cd:	84 c0                	test   %al,%al
 4cf:	0f 84 80 00 00 00    	je     555 <printf+0x171>
 4d5:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4d8:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 4db:	89 d3                	mov    %edx,%ebx
 4dd:	8d 76 00             	lea    0x0(%esi),%esi
 4e0:	88 45 e7             	mov    %al,-0x19(%ebp)
 4e3:	50                   	push   %eax
 4e4:	6a 01                	push   $0x1
 4e6:	57                   	push   %edi
 4e7:	56                   	push   %esi
 4e8:	e8 d2 fd ff ff       	call   2bf <write>
 4ed:	43                   	inc    %ebx
 4ee:	8a 03                	mov    (%ebx),%al
 4f0:	83 c4 10             	add    $0x10,%esp
 4f3:	84 c0                	test   %al,%al
 4f5:	75 e9                	jne    4e0 <printf+0xfc>
 4f7:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 4fa:	31 ff                	xor    %edi,%edi
 4fc:	e9 1b ff ff ff       	jmp    41c <printf+0x38>
 501:	8d 76 00             	lea    0x0(%esi),%esi
 504:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 507:	8b 17                	mov    (%edi),%edx
 509:	83 ec 0c             	sub    $0xc,%esp
 50c:	6a 01                	push   $0x1
 50e:	b9 0a 00 00 00       	mov    $0xa,%ecx
 513:	eb 8a                	jmp    49f <printf+0xbb>
 515:	8d 76 00             	lea    0x0(%esi),%esi
 518:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 51b:	8b 00                	mov    (%eax),%eax
 51d:	88 45 e7             	mov    %al,-0x19(%ebp)
 520:	51                   	push   %ecx
 521:	6a 01                	push   $0x1
 523:	8d 7d e7             	lea    -0x19(%ebp),%edi
 526:	57                   	push   %edi
 527:	56                   	push   %esi
 528:	e8 92 fd ff ff       	call   2bf <write>
 52d:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 531:	83 c4 10             	add    $0x10,%esp
 534:	31 ff                	xor    %edi,%edi
 536:	e9 e1 fe ff ff       	jmp    41c <printf+0x38>
 53b:	90                   	nop
 53c:	88 55 e7             	mov    %dl,-0x19(%ebp)
 53f:	52                   	push   %edx
 540:	6a 01                	push   $0x1
 542:	8d 7d e7             	lea    -0x19(%ebp),%edi
 545:	e9 35 ff ff ff       	jmp    47f <printf+0x9b>
 54a:	66 90                	xchg   %ax,%ax
 54c:	b0 28                	mov    $0x28,%al
 54e:	ba 1c 07 00 00       	mov    $0x71c,%edx
 553:	eb 80                	jmp    4d5 <printf+0xf1>
 555:	31 ff                	xor    %edi,%edi
 557:	e9 c0 fe ff ff       	jmp    41c <printf+0x38>

0000055c <free>:
 55c:	55                   	push   %ebp
 55d:	89 e5                	mov    %esp,%ebp
 55f:	57                   	push   %edi
 560:	56                   	push   %esi
 561:	53                   	push   %ebx
 562:	8b 5d 08             	mov    0x8(%ebp),%ebx
 565:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 568:	a1 90 07 00 00       	mov    0x790,%eax
 56d:	8d 76 00             	lea    0x0(%esi),%esi
 570:	89 c2                	mov    %eax,%edx
 572:	8b 00                	mov    (%eax),%eax
 574:	39 ca                	cmp    %ecx,%edx
 576:	73 2c                	jae    5a4 <free+0x48>
 578:	39 c1                	cmp    %eax,%ecx
 57a:	72 04                	jb     580 <free+0x24>
 57c:	39 c2                	cmp    %eax,%edx
 57e:	72 f0                	jb     570 <free+0x14>
 580:	8b 73 fc             	mov    -0x4(%ebx),%esi
 583:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 586:	39 f8                	cmp    %edi,%eax
 588:	74 2c                	je     5b6 <free+0x5a>
 58a:	89 43 f8             	mov    %eax,-0x8(%ebx)
 58d:	8b 42 04             	mov    0x4(%edx),%eax
 590:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 593:	39 f1                	cmp    %esi,%ecx
 595:	74 36                	je     5cd <free+0x71>
 597:	89 0a                	mov    %ecx,(%edx)
 599:	89 15 90 07 00 00    	mov    %edx,0x790
 59f:	5b                   	pop    %ebx
 5a0:	5e                   	pop    %esi
 5a1:	5f                   	pop    %edi
 5a2:	5d                   	pop    %ebp
 5a3:	c3                   	ret    
 5a4:	39 c2                	cmp    %eax,%edx
 5a6:	72 c8                	jb     570 <free+0x14>
 5a8:	39 c1                	cmp    %eax,%ecx
 5aa:	73 c4                	jae    570 <free+0x14>
 5ac:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5af:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5b2:	39 f8                	cmp    %edi,%eax
 5b4:	75 d4                	jne    58a <free+0x2e>
 5b6:	03 70 04             	add    0x4(%eax),%esi
 5b9:	89 73 fc             	mov    %esi,-0x4(%ebx)
 5bc:	8b 02                	mov    (%edx),%eax
 5be:	8b 00                	mov    (%eax),%eax
 5c0:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5c3:	8b 42 04             	mov    0x4(%edx),%eax
 5c6:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5c9:	39 f1                	cmp    %esi,%ecx
 5cb:	75 ca                	jne    597 <free+0x3b>
 5cd:	03 43 fc             	add    -0x4(%ebx),%eax
 5d0:	89 42 04             	mov    %eax,0x4(%edx)
 5d3:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 5d6:	89 0a                	mov    %ecx,(%edx)
 5d8:	89 15 90 07 00 00    	mov    %edx,0x790
 5de:	5b                   	pop    %ebx
 5df:	5e                   	pop    %esi
 5e0:	5f                   	pop    %edi
 5e1:	5d                   	pop    %ebp
 5e2:	c3                   	ret    
 5e3:	90                   	nop

000005e4 <malloc>:
 5e4:	55                   	push   %ebp
 5e5:	89 e5                	mov    %esp,%ebp
 5e7:	57                   	push   %edi
 5e8:	56                   	push   %esi
 5e9:	53                   	push   %ebx
 5ea:	83 ec 0c             	sub    $0xc,%esp
 5ed:	8b 45 08             	mov    0x8(%ebp),%eax
 5f0:	8d 78 07             	lea    0x7(%eax),%edi
 5f3:	c1 ef 03             	shr    $0x3,%edi
 5f6:	47                   	inc    %edi
 5f7:	8b 15 90 07 00 00    	mov    0x790,%edx
 5fd:	85 d2                	test   %edx,%edx
 5ff:	0f 84 93 00 00 00    	je     698 <malloc+0xb4>
 605:	8b 02                	mov    (%edx),%eax
 607:	8b 48 04             	mov    0x4(%eax),%ecx
 60a:	39 f9                	cmp    %edi,%ecx
 60c:	73 62                	jae    670 <malloc+0x8c>
 60e:	89 fb                	mov    %edi,%ebx
 610:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 616:	72 78                	jb     690 <malloc+0xac>
 618:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 61f:	eb 0e                	jmp    62f <malloc+0x4b>
 621:	8d 76 00             	lea    0x0(%esi),%esi
 624:	89 c2                	mov    %eax,%edx
 626:	8b 02                	mov    (%edx),%eax
 628:	8b 48 04             	mov    0x4(%eax),%ecx
 62b:	39 f9                	cmp    %edi,%ecx
 62d:	73 41                	jae    670 <malloc+0x8c>
 62f:	39 05 90 07 00 00    	cmp    %eax,0x790
 635:	75 ed                	jne    624 <malloc+0x40>
 637:	83 ec 0c             	sub    $0xc,%esp
 63a:	56                   	push   %esi
 63b:	e8 e7 fc ff ff       	call   327 <sbrk>
 640:	83 c4 10             	add    $0x10,%esp
 643:	83 f8 ff             	cmp    $0xffffffff,%eax
 646:	74 1c                	je     664 <malloc+0x80>
 648:	89 58 04             	mov    %ebx,0x4(%eax)
 64b:	83 ec 0c             	sub    $0xc,%esp
 64e:	83 c0 08             	add    $0x8,%eax
 651:	50                   	push   %eax
 652:	e8 05 ff ff ff       	call   55c <free>
 657:	8b 15 90 07 00 00    	mov    0x790,%edx
 65d:	83 c4 10             	add    $0x10,%esp
 660:	85 d2                	test   %edx,%edx
 662:	75 c2                	jne    626 <malloc+0x42>
 664:	31 c0                	xor    %eax,%eax
 666:	8d 65 f4             	lea    -0xc(%ebp),%esp
 669:	5b                   	pop    %ebx
 66a:	5e                   	pop    %esi
 66b:	5f                   	pop    %edi
 66c:	5d                   	pop    %ebp
 66d:	c3                   	ret    
 66e:	66 90                	xchg   %ax,%ax
 670:	39 cf                	cmp    %ecx,%edi
 672:	74 4c                	je     6c0 <malloc+0xdc>
 674:	29 f9                	sub    %edi,%ecx
 676:	89 48 04             	mov    %ecx,0x4(%eax)
 679:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 67c:	89 78 04             	mov    %edi,0x4(%eax)
 67f:	89 15 90 07 00 00    	mov    %edx,0x790
 685:	83 c0 08             	add    $0x8,%eax
 688:	8d 65 f4             	lea    -0xc(%ebp),%esp
 68b:	5b                   	pop    %ebx
 68c:	5e                   	pop    %esi
 68d:	5f                   	pop    %edi
 68e:	5d                   	pop    %ebp
 68f:	c3                   	ret    
 690:	bb 00 10 00 00       	mov    $0x1000,%ebx
 695:	eb 81                	jmp    618 <malloc+0x34>
 697:	90                   	nop
 698:	c7 05 90 07 00 00 94 	movl   $0x794,0x790
 69f:	07 00 00 
 6a2:	c7 05 94 07 00 00 94 	movl   $0x794,0x794
 6a9:	07 00 00 
 6ac:	c7 05 98 07 00 00 00 	movl   $0x0,0x798
 6b3:	00 00 00 
 6b6:	b8 94 07 00 00       	mov    $0x794,%eax
 6bb:	e9 4e ff ff ff       	jmp    60e <malloc+0x2a>
 6c0:	8b 08                	mov    (%eax),%ecx
 6c2:	89 0a                	mov    %ecx,(%edx)
 6c4:	eb b9                	jmp    67f <malloc+0x9b>
