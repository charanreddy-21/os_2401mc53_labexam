prottest.o: prottest.c types.h user.h
