
_kill:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 08             	sub    $0x8,%esp
  14:	8b 31                	mov    (%ecx),%esi
  16:	8b 79 04             	mov    0x4(%ecx),%edi
  19:	83 fe 01             	cmp    $0x1,%esi
  1c:	7e 26                	jle    44 <main+0x44>
  1e:	bb 01 00 00 00       	mov    $0x1,%ebx
  23:	90                   	nop
  24:	83 ec 0c             	sub    $0xc,%esp
  27:	ff 34 9f             	pushl  (%edi,%ebx,4)
  2a:	e8 8d 01 00 00       	call   1bc <atoi>
  2f:	89 04 24             	mov    %eax,(%esp)
  32:	e8 14 02 00 00       	call   24b <kill>
  37:	43                   	inc    %ebx
  38:	83 c4 10             	add    $0x10,%esp
  3b:	39 de                	cmp    %ebx,%esi
  3d:	75 e5                	jne    24 <main+0x24>
  3f:	e8 d7 01 00 00       	call   21b <exit>
  44:	50                   	push   %eax
  45:	50                   	push   %eax
  46:	68 44 06 00 00       	push   $0x644
  4b:	6a 02                	push   $0x2
  4d:	e8 0e 03 00 00       	call   360 <printf>
  52:	e8 c4 01 00 00       	call   21b <exit>
  57:	90                   	nop

00000058 <strcpy>:
  58:	55                   	push   %ebp
  59:	89 e5                	mov    %esp,%ebp
  5b:	53                   	push   %ebx
  5c:	8b 4d 08             	mov    0x8(%ebp),%ecx
  5f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  62:	31 c0                	xor    %eax,%eax
  64:	8a 14 03             	mov    (%ebx,%eax,1),%dl
  67:	88 14 01             	mov    %dl,(%ecx,%eax,1)
  6a:	40                   	inc    %eax
  6b:	84 d2                	test   %dl,%dl
  6d:	75 f5                	jne    64 <strcpy+0xc>
  6f:	89 c8                	mov    %ecx,%eax
  71:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  74:	c9                   	leave  
  75:	c3                   	ret    
  76:	66 90                	xchg   %ax,%ax

00000078 <strcmp>:
  78:	55                   	push   %ebp
  79:	89 e5                	mov    %esp,%ebp
  7b:	53                   	push   %ebx
  7c:	8b 55 08             	mov    0x8(%ebp),%edx
  7f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  82:	0f b6 02             	movzbl (%edx),%eax
  85:	84 c0                	test   %al,%al
  87:	75 10                	jne    99 <strcmp+0x21>
  89:	eb 2a                	jmp    b5 <strcmp+0x3d>
  8b:	90                   	nop
  8c:	42                   	inc    %edx
  8d:	8d 4b 01             	lea    0x1(%ebx),%ecx
  90:	0f b6 02             	movzbl (%edx),%eax
  93:	84 c0                	test   %al,%al
  95:	74 11                	je     a8 <strcmp+0x30>
  97:	89 cb                	mov    %ecx,%ebx
  99:	0f b6 0b             	movzbl (%ebx),%ecx
  9c:	38 c1                	cmp    %al,%cl
  9e:	74 ec                	je     8c <strcmp+0x14>
  a0:	29 c8                	sub    %ecx,%eax
  a2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  a5:	c9                   	leave  
  a6:	c3                   	ret    
  a7:	90                   	nop
  a8:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
  ac:	31 c0                	xor    %eax,%eax
  ae:	29 c8                	sub    %ecx,%eax
  b0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  b3:	c9                   	leave  
  b4:	c3                   	ret    
  b5:	0f b6 0b             	movzbl (%ebx),%ecx
  b8:	31 c0                	xor    %eax,%eax
  ba:	eb e4                	jmp    a0 <strcmp+0x28>

000000bc <strlen>:
  bc:	55                   	push   %ebp
  bd:	89 e5                	mov    %esp,%ebp
  bf:	8b 55 08             	mov    0x8(%ebp),%edx
  c2:	80 3a 00             	cmpb   $0x0,(%edx)
  c5:	74 15                	je     dc <strlen+0x20>
  c7:	31 c0                	xor    %eax,%eax
  c9:	8d 76 00             	lea    0x0(%esi),%esi
  cc:	40                   	inc    %eax
  cd:	89 c1                	mov    %eax,%ecx
  cf:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
  d3:	75 f7                	jne    cc <strlen+0x10>
  d5:	89 c8                	mov    %ecx,%eax
  d7:	5d                   	pop    %ebp
  d8:	c3                   	ret    
  d9:	8d 76 00             	lea    0x0(%esi),%esi
  dc:	31 c9                	xor    %ecx,%ecx
  de:	89 c8                	mov    %ecx,%eax
  e0:	5d                   	pop    %ebp
  e1:	c3                   	ret    
  e2:	66 90                	xchg   %ax,%ax

000000e4 <memset>:
  e4:	55                   	push   %ebp
  e5:	89 e5                	mov    %esp,%ebp
  e7:	57                   	push   %edi
  e8:	8b 7d 08             	mov    0x8(%ebp),%edi
  eb:	8b 4d 10             	mov    0x10(%ebp),%ecx
  ee:	8b 45 0c             	mov    0xc(%ebp),%eax
  f1:	fc                   	cld    
  f2:	f3 aa                	rep stos %al,%es:(%edi)
  f4:	8b 45 08             	mov    0x8(%ebp),%eax
  f7:	8b 7d fc             	mov    -0x4(%ebp),%edi
  fa:	c9                   	leave  
  fb:	c3                   	ret    

000000fc <strchr>:
  fc:	55                   	push   %ebp
  fd:	89 e5                	mov    %esp,%ebp
  ff:	8b 45 08             	mov    0x8(%ebp),%eax
 102:	8a 4d 0c             	mov    0xc(%ebp),%cl
 105:	8a 10                	mov    (%eax),%dl
 107:	84 d2                	test   %dl,%dl
 109:	75 0c                	jne    117 <strchr+0x1b>
 10b:	eb 13                	jmp    120 <strchr+0x24>
 10d:	8d 76 00             	lea    0x0(%esi),%esi
 110:	40                   	inc    %eax
 111:	8a 10                	mov    (%eax),%dl
 113:	84 d2                	test   %dl,%dl
 115:	74 09                	je     120 <strchr+0x24>
 117:	38 d1                	cmp    %dl,%cl
 119:	75 f5                	jne    110 <strchr+0x14>
 11b:	5d                   	pop    %ebp
 11c:	c3                   	ret    
 11d:	8d 76 00             	lea    0x0(%esi),%esi
 120:	31 c0                	xor    %eax,%eax
 122:	5d                   	pop    %ebp
 123:	c3                   	ret    

00000124 <gets>:
 124:	55                   	push   %ebp
 125:	89 e5                	mov    %esp,%ebp
 127:	57                   	push   %edi
 128:	56                   	push   %esi
 129:	53                   	push   %ebx
 12a:	83 ec 1c             	sub    $0x1c,%esp
 12d:	31 db                	xor    %ebx,%ebx
 12f:	8d 75 e7             	lea    -0x19(%ebp),%esi
 132:	eb 24                	jmp    158 <gets+0x34>
 134:	50                   	push   %eax
 135:	6a 01                	push   $0x1
 137:	56                   	push   %esi
 138:	6a 00                	push   $0x0
 13a:	e8 f4 00 00 00       	call   233 <read>
 13f:	83 c4 10             	add    $0x10,%esp
 142:	85 c0                	test   %eax,%eax
 144:	7e 1a                	jle    160 <gets+0x3c>
 146:	8a 45 e7             	mov    -0x19(%ebp),%al
 149:	8b 55 08             	mov    0x8(%ebp),%edx
 14c:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 150:	3c 0a                	cmp    $0xa,%al
 152:	74 0e                	je     162 <gets+0x3e>
 154:	3c 0d                	cmp    $0xd,%al
 156:	74 0a                	je     162 <gets+0x3e>
 158:	89 df                	mov    %ebx,%edi
 15a:	43                   	inc    %ebx
 15b:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 15e:	7c d4                	jl     134 <gets+0x10>
 160:	89 fb                	mov    %edi,%ebx
 162:	8b 45 08             	mov    0x8(%ebp),%eax
 165:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 169:	8d 65 f4             	lea    -0xc(%ebp),%esp
 16c:	5b                   	pop    %ebx
 16d:	5e                   	pop    %esi
 16e:	5f                   	pop    %edi
 16f:	5d                   	pop    %ebp
 170:	c3                   	ret    
 171:	8d 76 00             	lea    0x0(%esi),%esi

00000174 <stat>:
 174:	55                   	push   %ebp
 175:	89 e5                	mov    %esp,%ebp
 177:	56                   	push   %esi
 178:	53                   	push   %ebx
 179:	83 ec 08             	sub    $0x8,%esp
 17c:	6a 00                	push   $0x0
 17e:	ff 75 08             	pushl  0x8(%ebp)
 181:	e8 d5 00 00 00       	call   25b <open>
 186:	83 c4 10             	add    $0x10,%esp
 189:	85 c0                	test   %eax,%eax
 18b:	78 27                	js     1b4 <stat+0x40>
 18d:	89 c3                	mov    %eax,%ebx
 18f:	83 ec 08             	sub    $0x8,%esp
 192:	ff 75 0c             	pushl  0xc(%ebp)
 195:	50                   	push   %eax
 196:	e8 d8 00 00 00       	call   273 <fstat>
 19b:	89 c6                	mov    %eax,%esi
 19d:	89 1c 24             	mov    %ebx,(%esp)
 1a0:	e8 9e 00 00 00       	call   243 <close>
 1a5:	83 c4 10             	add    $0x10,%esp
 1a8:	89 f0                	mov    %esi,%eax
 1aa:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1ad:	5b                   	pop    %ebx
 1ae:	5e                   	pop    %esi
 1af:	5d                   	pop    %ebp
 1b0:	c3                   	ret    
 1b1:	8d 76 00             	lea    0x0(%esi),%esi
 1b4:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1b9:	eb ed                	jmp    1a8 <stat+0x34>
 1bb:	90                   	nop

000001bc <atoi>:
 1bc:	55                   	push   %ebp
 1bd:	89 e5                	mov    %esp,%ebp
 1bf:	53                   	push   %ebx
 1c0:	8b 4d 08             	mov    0x8(%ebp),%ecx
 1c3:	0f be 01             	movsbl (%ecx),%eax
 1c6:	8d 50 d0             	lea    -0x30(%eax),%edx
 1c9:	80 fa 09             	cmp    $0x9,%dl
 1cc:	ba 00 00 00 00       	mov    $0x0,%edx
 1d1:	77 16                	ja     1e9 <atoi+0x2d>
 1d3:	90                   	nop
 1d4:	41                   	inc    %ecx
 1d5:	8d 14 92             	lea    (%edx,%edx,4),%edx
 1d8:	01 d2                	add    %edx,%edx
 1da:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 1de:	0f be 01             	movsbl (%ecx),%eax
 1e1:	8d 58 d0             	lea    -0x30(%eax),%ebx
 1e4:	80 fb 09             	cmp    $0x9,%bl
 1e7:	76 eb                	jbe    1d4 <atoi+0x18>
 1e9:	89 d0                	mov    %edx,%eax
 1eb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1ee:	c9                   	leave  
 1ef:	c3                   	ret    

000001f0 <memmove>:
 1f0:	55                   	push   %ebp
 1f1:	89 e5                	mov    %esp,%ebp
 1f3:	57                   	push   %edi
 1f4:	56                   	push   %esi
 1f5:	8b 55 08             	mov    0x8(%ebp),%edx
 1f8:	8b 75 0c             	mov    0xc(%ebp),%esi
 1fb:	8b 45 10             	mov    0x10(%ebp),%eax
 1fe:	85 c0                	test   %eax,%eax
 200:	7e 0b                	jle    20d <memmove+0x1d>
 202:	01 d0                	add    %edx,%eax
 204:	89 d7                	mov    %edx,%edi
 206:	66 90                	xchg   %ax,%ax
 208:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 209:	39 f8                	cmp    %edi,%eax
 20b:	75 fb                	jne    208 <memmove+0x18>
 20d:	89 d0                	mov    %edx,%eax
 20f:	5e                   	pop    %esi
 210:	5f                   	pop    %edi
 211:	5d                   	pop    %ebp
 212:	c3                   	ret    

00000213 <fork>:
 213:	b8 01 00 00 00       	mov    $0x1,%eax
 218:	cd 40                	int    $0x40
 21a:	c3                   	ret    

0000021b <exit>:
 21b:	b8 02 00 00 00       	mov    $0x2,%eax
 220:	cd 40                	int    $0x40
 222:	c3                   	ret    

00000223 <wait>:
 223:	b8 03 00 00 00       	mov    $0x3,%eax
 228:	cd 40                	int    $0x40
 22a:	c3                   	ret    

0000022b <pipe>:
 22b:	b8 04 00 00 00       	mov    $0x4,%eax
 230:	cd 40                	int    $0x40
 232:	c3                   	ret    

00000233 <read>:
 233:	b8 05 00 00 00       	mov    $0x5,%eax
 238:	cd 40                	int    $0x40
 23a:	c3                   	ret    

0000023b <write>:
 23b:	b8 10 00 00 00       	mov    $0x10,%eax
 240:	cd 40                	int    $0x40
 242:	c3                   	ret    

00000243 <close>:
 243:	b8 15 00 00 00       	mov    $0x15,%eax
 248:	cd 40                	int    $0x40
 24a:	c3                   	ret    

0000024b <kill>:
 24b:	b8 06 00 00 00       	mov    $0x6,%eax
 250:	cd 40                	int    $0x40
 252:	c3                   	ret    

00000253 <exec>:
 253:	b8 07 00 00 00       	mov    $0x7,%eax
 258:	cd 40                	int    $0x40
 25a:	c3                   	ret    

0000025b <open>:
 25b:	b8 0f 00 00 00       	mov    $0xf,%eax
 260:	cd 40                	int    $0x40
 262:	c3                   	ret    

00000263 <mknod>:
 263:	b8 11 00 00 00       	mov    $0x11,%eax
 268:	cd 40                	int    $0x40
 26a:	c3                   	ret    

0000026b <unlink>:
 26b:	b8 12 00 00 00       	mov    $0x12,%eax
 270:	cd 40                	int    $0x40
 272:	c3                   	ret    

00000273 <fstat>:
 273:	b8 08 00 00 00       	mov    $0x8,%eax
 278:	cd 40                	int    $0x40
 27a:	c3                   	ret    

0000027b <link>:
 27b:	b8 13 00 00 00       	mov    $0x13,%eax
 280:	cd 40                	int    $0x40
 282:	c3                   	ret    

00000283 <mkdir>:
 283:	b8 14 00 00 00       	mov    $0x14,%eax
 288:	cd 40                	int    $0x40
 28a:	c3                   	ret    

0000028b <chdir>:
 28b:	b8 09 00 00 00       	mov    $0x9,%eax
 290:	cd 40                	int    $0x40
 292:	c3                   	ret    

00000293 <dup>:
 293:	b8 0a 00 00 00       	mov    $0xa,%eax
 298:	cd 40                	int    $0x40
 29a:	c3                   	ret    

0000029b <getpid>:
 29b:	b8 0b 00 00 00       	mov    $0xb,%eax
 2a0:	cd 40                	int    $0x40
 2a2:	c3                   	ret    

000002a3 <sbrk>:
 2a3:	b8 0c 00 00 00       	mov    $0xc,%eax
 2a8:	cd 40                	int    $0x40
 2aa:	c3                   	ret    

000002ab <sleep>:
 2ab:	b8 0d 00 00 00       	mov    $0xd,%eax
 2b0:	cd 40                	int    $0x40
 2b2:	c3                   	ret    

000002b3 <uptime>:
 2b3:	b8 0e 00 00 00       	mov    $0xe,%eax
 2b8:	cd 40                	int    $0x40
 2ba:	c3                   	ret    

000002bb <mprotect>:
 2bb:	b8 16 00 00 00       	mov    $0x16,%eax
 2c0:	cd 40                	int    $0x40
 2c2:	c3                   	ret    

000002c3 <munprotect>:
 2c3:	b8 17 00 00 00       	mov    $0x17,%eax
 2c8:	cd 40                	int    $0x40
 2ca:	c3                   	ret    

000002cb <set_priority>:
 2cb:	b8 18 00 00 00       	mov    $0x18,%eax
 2d0:	cd 40                	int    $0x40
 2d2:	c3                   	ret    
 2d3:	90                   	nop

000002d4 <printint>:
 2d4:	55                   	push   %ebp
 2d5:	89 e5                	mov    %esp,%ebp
 2d7:	57                   	push   %edi
 2d8:	56                   	push   %esi
 2d9:	53                   	push   %ebx
 2da:	83 ec 3c             	sub    $0x3c,%esp
 2dd:	89 45 c0             	mov    %eax,-0x40(%ebp)
 2e0:	89 cb                	mov    %ecx,%ebx
 2e2:	8b 4d 08             	mov    0x8(%ebp),%ecx
 2e5:	85 c9                	test   %ecx,%ecx
 2e7:	74 04                	je     2ed <printint+0x19>
 2e9:	85 d2                	test   %edx,%edx
 2eb:	78 6b                	js     358 <printint+0x84>
 2ed:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 2f0:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 2f7:	31 c9                	xor    %ecx,%ecx
 2f9:	8d 75 d7             	lea    -0x29(%ebp),%esi
 2fc:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 2ff:	31 d2                	xor    %edx,%edx
 301:	f7 f3                	div    %ebx
 303:	89 cf                	mov    %ecx,%edi
 305:	8d 49 01             	lea    0x1(%ecx),%ecx
 308:	8a 92 b8 06 00 00    	mov    0x6b8(%edx),%dl
 30e:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 312:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 315:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 318:	39 da                	cmp    %ebx,%edx
 31a:	73 e0                	jae    2fc <printint+0x28>
 31c:	8b 55 08             	mov    0x8(%ebp),%edx
 31f:	85 d2                	test   %edx,%edx
 321:	74 07                	je     32a <printint+0x56>
 323:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 328:	89 cf                	mov    %ecx,%edi
 32a:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 32d:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 331:	8d 76 00             	lea    0x0(%esi),%esi
 334:	8a 07                	mov    (%edi),%al
 336:	88 45 d7             	mov    %al,-0x29(%ebp)
 339:	50                   	push   %eax
 33a:	6a 01                	push   $0x1
 33c:	56                   	push   %esi
 33d:	ff 75 c0             	pushl  -0x40(%ebp)
 340:	e8 f6 fe ff ff       	call   23b <write>
 345:	89 f8                	mov    %edi,%eax
 347:	4f                   	dec    %edi
 348:	83 c4 10             	add    $0x10,%esp
 34b:	39 d8                	cmp    %ebx,%eax
 34d:	75 e5                	jne    334 <printint+0x60>
 34f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 352:	5b                   	pop    %ebx
 353:	5e                   	pop    %esi
 354:	5f                   	pop    %edi
 355:	5d                   	pop    %ebp
 356:	c3                   	ret    
 357:	90                   	nop
 358:	f7 da                	neg    %edx
 35a:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 35d:	eb 98                	jmp    2f7 <printint+0x23>
 35f:	90                   	nop

00000360 <printf>:
 360:	55                   	push   %ebp
 361:	89 e5                	mov    %esp,%ebp
 363:	57                   	push   %edi
 364:	56                   	push   %esi
 365:	53                   	push   %ebx
 366:	83 ec 2c             	sub    $0x2c,%esp
 369:	8b 75 08             	mov    0x8(%ebp),%esi
 36c:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 36f:	8a 13                	mov    (%ebx),%dl
 371:	84 d2                	test   %dl,%dl
 373:	74 5c                	je     3d1 <printf+0x71>
 375:	43                   	inc    %ebx
 376:	8d 45 10             	lea    0x10(%ebp),%eax
 379:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 37c:	31 ff                	xor    %edi,%edi
 37e:	eb 20                	jmp    3a0 <printf+0x40>
 380:	83 f8 25             	cmp    $0x25,%eax
 383:	74 3f                	je     3c4 <printf+0x64>
 385:	88 55 e7             	mov    %dl,-0x19(%ebp)
 388:	50                   	push   %eax
 389:	6a 01                	push   $0x1
 38b:	8d 45 e7             	lea    -0x19(%ebp),%eax
 38e:	50                   	push   %eax
 38f:	56                   	push   %esi
 390:	e8 a6 fe ff ff       	call   23b <write>
 395:	83 c4 10             	add    $0x10,%esp
 398:	43                   	inc    %ebx
 399:	8a 53 ff             	mov    -0x1(%ebx),%dl
 39c:	84 d2                	test   %dl,%dl
 39e:	74 31                	je     3d1 <printf+0x71>
 3a0:	0f b6 c2             	movzbl %dl,%eax
 3a3:	85 ff                	test   %edi,%edi
 3a5:	74 d9                	je     380 <printf+0x20>
 3a7:	83 ff 25             	cmp    $0x25,%edi
 3aa:	75 ec                	jne    398 <printf+0x38>
 3ac:	83 f8 25             	cmp    $0x25,%eax
 3af:	0f 84 03 01 00 00    	je     4b8 <printf+0x158>
 3b5:	83 e8 63             	sub    $0x63,%eax
 3b8:	83 f8 15             	cmp    $0x15,%eax
 3bb:	77 1f                	ja     3dc <printf+0x7c>
 3bd:	ff 24 85 60 06 00 00 	jmp    *0x660(,%eax,4)
 3c4:	bf 25 00 00 00       	mov    $0x25,%edi
 3c9:	43                   	inc    %ebx
 3ca:	8a 53 ff             	mov    -0x1(%ebx),%dl
 3cd:	84 d2                	test   %dl,%dl
 3cf:	75 cf                	jne    3a0 <printf+0x40>
 3d1:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3d4:	5b                   	pop    %ebx
 3d5:	5e                   	pop    %esi
 3d6:	5f                   	pop    %edi
 3d7:	5d                   	pop    %ebp
 3d8:	c3                   	ret    
 3d9:	8d 76 00             	lea    0x0(%esi),%esi
 3dc:	88 55 d0             	mov    %dl,-0x30(%ebp)
 3df:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 3e3:	50                   	push   %eax
 3e4:	6a 01                	push   $0x1
 3e6:	8d 7d e7             	lea    -0x19(%ebp),%edi
 3e9:	57                   	push   %edi
 3ea:	56                   	push   %esi
 3eb:	e8 4b fe ff ff       	call   23b <write>
 3f0:	8a 55 d0             	mov    -0x30(%ebp),%dl
 3f3:	88 55 e7             	mov    %dl,-0x19(%ebp)
 3f6:	83 c4 0c             	add    $0xc,%esp
 3f9:	6a 01                	push   $0x1
 3fb:	57                   	push   %edi
 3fc:	56                   	push   %esi
 3fd:	e8 39 fe ff ff       	call   23b <write>
 402:	83 c4 10             	add    $0x10,%esp
 405:	31 ff                	xor    %edi,%edi
 407:	eb 8f                	jmp    398 <printf+0x38>
 409:	8d 76 00             	lea    0x0(%esi),%esi
 40c:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 40f:	8b 17                	mov    (%edi),%edx
 411:	83 ec 0c             	sub    $0xc,%esp
 414:	6a 00                	push   $0x0
 416:	b9 10 00 00 00       	mov    $0x10,%ecx
 41b:	89 f0                	mov    %esi,%eax
 41d:	e8 b2 fe ff ff       	call   2d4 <printint>
 422:	83 c7 04             	add    $0x4,%edi
 425:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 428:	83 c4 10             	add    $0x10,%esp
 42b:	31 ff                	xor    %edi,%edi
 42d:	e9 66 ff ff ff       	jmp    398 <printf+0x38>
 432:	66 90                	xchg   %ax,%ax
 434:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 437:	8b 10                	mov    (%eax),%edx
 439:	83 c0 04             	add    $0x4,%eax
 43c:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 43f:	85 d2                	test   %edx,%edx
 441:	0f 84 81 00 00 00    	je     4c8 <printf+0x168>
 447:	8a 02                	mov    (%edx),%al
 449:	84 c0                	test   %al,%al
 44b:	0f 84 80 00 00 00    	je     4d1 <printf+0x171>
 451:	8d 7d e7             	lea    -0x19(%ebp),%edi
 454:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 457:	89 d3                	mov    %edx,%ebx
 459:	8d 76 00             	lea    0x0(%esi),%esi
 45c:	88 45 e7             	mov    %al,-0x19(%ebp)
 45f:	50                   	push   %eax
 460:	6a 01                	push   $0x1
 462:	57                   	push   %edi
 463:	56                   	push   %esi
 464:	e8 d2 fd ff ff       	call   23b <write>
 469:	43                   	inc    %ebx
 46a:	8a 03                	mov    (%ebx),%al
 46c:	83 c4 10             	add    $0x10,%esp
 46f:	84 c0                	test   %al,%al
 471:	75 e9                	jne    45c <printf+0xfc>
 473:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 476:	31 ff                	xor    %edi,%edi
 478:	e9 1b ff ff ff       	jmp    398 <printf+0x38>
 47d:	8d 76 00             	lea    0x0(%esi),%esi
 480:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 483:	8b 17                	mov    (%edi),%edx
 485:	83 ec 0c             	sub    $0xc,%esp
 488:	6a 01                	push   $0x1
 48a:	b9 0a 00 00 00       	mov    $0xa,%ecx
 48f:	eb 8a                	jmp    41b <printf+0xbb>
 491:	8d 76 00             	lea    0x0(%esi),%esi
 494:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 497:	8b 00                	mov    (%eax),%eax
 499:	88 45 e7             	mov    %al,-0x19(%ebp)
 49c:	51                   	push   %ecx
 49d:	6a 01                	push   $0x1
 49f:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4a2:	57                   	push   %edi
 4a3:	56                   	push   %esi
 4a4:	e8 92 fd ff ff       	call   23b <write>
 4a9:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 4ad:	83 c4 10             	add    $0x10,%esp
 4b0:	31 ff                	xor    %edi,%edi
 4b2:	e9 e1 fe ff ff       	jmp    398 <printf+0x38>
 4b7:	90                   	nop
 4b8:	88 55 e7             	mov    %dl,-0x19(%ebp)
 4bb:	52                   	push   %edx
 4bc:	6a 01                	push   $0x1
 4be:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4c1:	e9 35 ff ff ff       	jmp    3fb <printf+0x9b>
 4c6:	66 90                	xchg   %ax,%ax
 4c8:	b0 28                	mov    $0x28,%al
 4ca:	ba 58 06 00 00       	mov    $0x658,%edx
 4cf:	eb 80                	jmp    451 <printf+0xf1>
 4d1:	31 ff                	xor    %edi,%edi
 4d3:	e9 c0 fe ff ff       	jmp    398 <printf+0x38>

000004d8 <free>:
 4d8:	55                   	push   %ebp
 4d9:	89 e5                	mov    %esp,%ebp
 4db:	57                   	push   %edi
 4dc:	56                   	push   %esi
 4dd:	53                   	push   %ebx
 4de:	8b 5d 08             	mov    0x8(%ebp),%ebx
 4e1:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 4e4:	a1 cc 06 00 00       	mov    0x6cc,%eax
 4e9:	8d 76 00             	lea    0x0(%esi),%esi
 4ec:	89 c2                	mov    %eax,%edx
 4ee:	8b 00                	mov    (%eax),%eax
 4f0:	39 ca                	cmp    %ecx,%edx
 4f2:	73 2c                	jae    520 <free+0x48>
 4f4:	39 c1                	cmp    %eax,%ecx
 4f6:	72 04                	jb     4fc <free+0x24>
 4f8:	39 c2                	cmp    %eax,%edx
 4fa:	72 f0                	jb     4ec <free+0x14>
 4fc:	8b 73 fc             	mov    -0x4(%ebx),%esi
 4ff:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 502:	39 f8                	cmp    %edi,%eax
 504:	74 2c                	je     532 <free+0x5a>
 506:	89 43 f8             	mov    %eax,-0x8(%ebx)
 509:	8b 42 04             	mov    0x4(%edx),%eax
 50c:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 50f:	39 f1                	cmp    %esi,%ecx
 511:	74 36                	je     549 <free+0x71>
 513:	89 0a                	mov    %ecx,(%edx)
 515:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 51b:	5b                   	pop    %ebx
 51c:	5e                   	pop    %esi
 51d:	5f                   	pop    %edi
 51e:	5d                   	pop    %ebp
 51f:	c3                   	ret    
 520:	39 c2                	cmp    %eax,%edx
 522:	72 c8                	jb     4ec <free+0x14>
 524:	39 c1                	cmp    %eax,%ecx
 526:	73 c4                	jae    4ec <free+0x14>
 528:	8b 73 fc             	mov    -0x4(%ebx),%esi
 52b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 52e:	39 f8                	cmp    %edi,%eax
 530:	75 d4                	jne    506 <free+0x2e>
 532:	03 70 04             	add    0x4(%eax),%esi
 535:	89 73 fc             	mov    %esi,-0x4(%ebx)
 538:	8b 02                	mov    (%edx),%eax
 53a:	8b 00                	mov    (%eax),%eax
 53c:	89 43 f8             	mov    %eax,-0x8(%ebx)
 53f:	8b 42 04             	mov    0x4(%edx),%eax
 542:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 545:	39 f1                	cmp    %esi,%ecx
 547:	75 ca                	jne    513 <free+0x3b>
 549:	03 43 fc             	add    -0x4(%ebx),%eax
 54c:	89 42 04             	mov    %eax,0x4(%edx)
 54f:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 552:	89 0a                	mov    %ecx,(%edx)
 554:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 55a:	5b                   	pop    %ebx
 55b:	5e                   	pop    %esi
 55c:	5f                   	pop    %edi
 55d:	5d                   	pop    %ebp
 55e:	c3                   	ret    
 55f:	90                   	nop

00000560 <malloc>:
 560:	55                   	push   %ebp
 561:	89 e5                	mov    %esp,%ebp
 563:	57                   	push   %edi
 564:	56                   	push   %esi
 565:	53                   	push   %ebx
 566:	83 ec 0c             	sub    $0xc,%esp
 569:	8b 45 08             	mov    0x8(%ebp),%eax
 56c:	8d 78 07             	lea    0x7(%eax),%edi
 56f:	c1 ef 03             	shr    $0x3,%edi
 572:	47                   	inc    %edi
 573:	8b 15 cc 06 00 00    	mov    0x6cc,%edx
 579:	85 d2                	test   %edx,%edx
 57b:	0f 84 93 00 00 00    	je     614 <malloc+0xb4>
 581:	8b 02                	mov    (%edx),%eax
 583:	8b 48 04             	mov    0x4(%eax),%ecx
 586:	39 f9                	cmp    %edi,%ecx
 588:	73 62                	jae    5ec <malloc+0x8c>
 58a:	89 fb                	mov    %edi,%ebx
 58c:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 592:	72 78                	jb     60c <malloc+0xac>
 594:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 59b:	eb 0e                	jmp    5ab <malloc+0x4b>
 59d:	8d 76 00             	lea    0x0(%esi),%esi
 5a0:	89 c2                	mov    %eax,%edx
 5a2:	8b 02                	mov    (%edx),%eax
 5a4:	8b 48 04             	mov    0x4(%eax),%ecx
 5a7:	39 f9                	cmp    %edi,%ecx
 5a9:	73 41                	jae    5ec <malloc+0x8c>
 5ab:	39 05 cc 06 00 00    	cmp    %eax,0x6cc
 5b1:	75 ed                	jne    5a0 <malloc+0x40>
 5b3:	83 ec 0c             	sub    $0xc,%esp
 5b6:	56                   	push   %esi
 5b7:	e8 e7 fc ff ff       	call   2a3 <sbrk>
 5bc:	83 c4 10             	add    $0x10,%esp
 5bf:	83 f8 ff             	cmp    $0xffffffff,%eax
 5c2:	74 1c                	je     5e0 <malloc+0x80>
 5c4:	89 58 04             	mov    %ebx,0x4(%eax)
 5c7:	83 ec 0c             	sub    $0xc,%esp
 5ca:	83 c0 08             	add    $0x8,%eax
 5cd:	50                   	push   %eax
 5ce:	e8 05 ff ff ff       	call   4d8 <free>
 5d3:	8b 15 cc 06 00 00    	mov    0x6cc,%edx
 5d9:	83 c4 10             	add    $0x10,%esp
 5dc:	85 d2                	test   %edx,%edx
 5de:	75 c2                	jne    5a2 <malloc+0x42>
 5e0:	31 c0                	xor    %eax,%eax
 5e2:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5e5:	5b                   	pop    %ebx
 5e6:	5e                   	pop    %esi
 5e7:	5f                   	pop    %edi
 5e8:	5d                   	pop    %ebp
 5e9:	c3                   	ret    
 5ea:	66 90                	xchg   %ax,%ax
 5ec:	39 cf                	cmp    %ecx,%edi
 5ee:	74 4c                	je     63c <malloc+0xdc>
 5f0:	29 f9                	sub    %edi,%ecx
 5f2:	89 48 04             	mov    %ecx,0x4(%eax)
 5f5:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 5f8:	89 78 04             	mov    %edi,0x4(%eax)
 5fb:	89 15 cc 06 00 00    	mov    %edx,0x6cc
 601:	83 c0 08             	add    $0x8,%eax
 604:	8d 65 f4             	lea    -0xc(%ebp),%esp
 607:	5b                   	pop    %ebx
 608:	5e                   	pop    %esi
 609:	5f                   	pop    %edi
 60a:	5d                   	pop    %ebp
 60b:	c3                   	ret    
 60c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 611:	eb 81                	jmp    594 <malloc+0x34>
 613:	90                   	nop
 614:	c7 05 cc 06 00 00 d0 	movl   $0x6d0,0x6cc
 61b:	06 00 00 
 61e:	c7 05 d0 06 00 00 d0 	movl   $0x6d0,0x6d0
 625:	06 00 00 
 628:	c7 05 d4 06 00 00 00 	movl   $0x0,0x6d4
 62f:	00 00 00 
 632:	b8 d0 06 00 00       	mov    $0x6d0,%eax
 637:	e9 4e ff ff ff       	jmp    58a <malloc+0x2a>
 63c:	8b 08                	mov    (%eax),%ecx
 63e:	89 0a                	mov    %ecx,(%edx)
 640:	eb b9                	jmp    5fb <malloc+0x9b>
