
_cat:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
  14:	8b 01                	mov    (%ecx),%eax
  16:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  19:	8b 59 04             	mov    0x4(%ecx),%ebx
  1c:	48                   	dec    %eax
  1d:	7e 58                	jle    77 <main+0x77>
  1f:	83 c3 04             	add    $0x4,%ebx
  22:	be 01 00 00 00       	mov    $0x1,%esi
  27:	eb 20                	jmp    49 <main+0x49>
  29:	8d 76 00             	lea    0x0(%esi),%esi
  2c:	83 ec 0c             	sub    $0xc,%esp
  2f:	50                   	push   %eax
  30:	e8 53 00 00 00       	call   88 <cat>
  35:	89 3c 24             	mov    %edi,(%esp)
  38:	e8 a2 02 00 00       	call   2df <close>
  3d:	46                   	inc    %esi
  3e:	83 c3 04             	add    $0x4,%ebx
  41:	83 c4 10             	add    $0x10,%esp
  44:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
  47:	74 29                	je     72 <main+0x72>
  49:	83 ec 08             	sub    $0x8,%esp
  4c:	6a 00                	push   $0x0
  4e:	ff 33                	pushl  (%ebx)
  50:	e8 a2 02 00 00       	call   2f7 <open>
  55:	89 c7                	mov    %eax,%edi
  57:	83 c4 10             	add    $0x10,%esp
  5a:	85 c0                	test   %eax,%eax
  5c:	79 ce                	jns    2c <main+0x2c>
  5e:	50                   	push   %eax
  5f:	ff 33                	pushl  (%ebx)
  61:	68 03 07 00 00       	push   $0x703
  66:	6a 01                	push   $0x1
  68:	e8 8f 03 00 00       	call   3fc <printf>
  6d:	e8 45 02 00 00       	call   2b7 <exit>
  72:	e8 40 02 00 00       	call   2b7 <exit>
  77:	83 ec 0c             	sub    $0xc,%esp
  7a:	6a 00                	push   $0x0
  7c:	e8 07 00 00 00       	call   88 <cat>
  81:	e8 31 02 00 00       	call   2b7 <exit>
  86:	66 90                	xchg   %ax,%ax

00000088 <cat>:
  88:	55                   	push   %ebp
  89:	89 e5                	mov    %esp,%ebp
  8b:	56                   	push   %esi
  8c:	53                   	push   %ebx
  8d:	8b 75 08             	mov    0x8(%ebp),%esi
  90:	eb 17                	jmp    a9 <cat+0x21>
  92:	66 90                	xchg   %ax,%ax
  94:	51                   	push   %ecx
  95:	53                   	push   %ebx
  96:	68 a0 07 00 00       	push   $0x7a0
  9b:	6a 01                	push   $0x1
  9d:	e8 35 02 00 00       	call   2d7 <write>
  a2:	83 c4 10             	add    $0x10,%esp
  a5:	39 d8                	cmp    %ebx,%eax
  a7:	75 23                	jne    cc <cat+0x44>
  a9:	52                   	push   %edx
  aa:	68 00 02 00 00       	push   $0x200
  af:	68 a0 07 00 00       	push   $0x7a0
  b4:	56                   	push   %esi
  b5:	e8 15 02 00 00       	call   2cf <read>
  ba:	89 c3                	mov    %eax,%ebx
  bc:	83 c4 10             	add    $0x10,%esp
  bf:	85 c0                	test   %eax,%eax
  c1:	7f d1                	jg     94 <cat+0xc>
  c3:	75 1b                	jne    e0 <cat+0x58>
  c5:	8d 65 f8             	lea    -0x8(%ebp),%esp
  c8:	5b                   	pop    %ebx
  c9:	5e                   	pop    %esi
  ca:	5d                   	pop    %ebp
  cb:	c3                   	ret    
  cc:	83 ec 08             	sub    $0x8,%esp
  cf:	68 e0 06 00 00       	push   $0x6e0
  d4:	6a 01                	push   $0x1
  d6:	e8 21 03 00 00       	call   3fc <printf>
  db:	e8 d7 01 00 00       	call   2b7 <exit>
  e0:	50                   	push   %eax
  e1:	50                   	push   %eax
  e2:	68 f2 06 00 00       	push   $0x6f2
  e7:	6a 01                	push   $0x1
  e9:	e8 0e 03 00 00       	call   3fc <printf>
  ee:	e8 c4 01 00 00       	call   2b7 <exit>
  f3:	90                   	nop

000000f4 <strcpy>:
  f4:	55                   	push   %ebp
  f5:	89 e5                	mov    %esp,%ebp
  f7:	53                   	push   %ebx
  f8:	8b 4d 08             	mov    0x8(%ebp),%ecx
  fb:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  fe:	31 c0                	xor    %eax,%eax
 100:	8a 14 03             	mov    (%ebx,%eax,1),%dl
 103:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 106:	40                   	inc    %eax
 107:	84 d2                	test   %dl,%dl
 109:	75 f5                	jne    100 <strcpy+0xc>
 10b:	89 c8                	mov    %ecx,%eax
 10d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 110:	c9                   	leave  
 111:	c3                   	ret    
 112:	66 90                	xchg   %ax,%ax

00000114 <strcmp>:
 114:	55                   	push   %ebp
 115:	89 e5                	mov    %esp,%ebp
 117:	53                   	push   %ebx
 118:	8b 55 08             	mov    0x8(%ebp),%edx
 11b:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 11e:	0f b6 02             	movzbl (%edx),%eax
 121:	84 c0                	test   %al,%al
 123:	75 10                	jne    135 <strcmp+0x21>
 125:	eb 2a                	jmp    151 <strcmp+0x3d>
 127:	90                   	nop
 128:	42                   	inc    %edx
 129:	8d 4b 01             	lea    0x1(%ebx),%ecx
 12c:	0f b6 02             	movzbl (%edx),%eax
 12f:	84 c0                	test   %al,%al
 131:	74 11                	je     144 <strcmp+0x30>
 133:	89 cb                	mov    %ecx,%ebx
 135:	0f b6 0b             	movzbl (%ebx),%ecx
 138:	38 c1                	cmp    %al,%cl
 13a:	74 ec                	je     128 <strcmp+0x14>
 13c:	29 c8                	sub    %ecx,%eax
 13e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 141:	c9                   	leave  
 142:	c3                   	ret    
 143:	90                   	nop
 144:	0f b6 4b 01          	movzbl 0x1(%ebx),%ecx
 148:	31 c0                	xor    %eax,%eax
 14a:	29 c8                	sub    %ecx,%eax
 14c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 14f:	c9                   	leave  
 150:	c3                   	ret    
 151:	0f b6 0b             	movzbl (%ebx),%ecx
 154:	31 c0                	xor    %eax,%eax
 156:	eb e4                	jmp    13c <strcmp+0x28>

00000158 <strlen>:
 158:	55                   	push   %ebp
 159:	89 e5                	mov    %esp,%ebp
 15b:	8b 55 08             	mov    0x8(%ebp),%edx
 15e:	80 3a 00             	cmpb   $0x0,(%edx)
 161:	74 15                	je     178 <strlen+0x20>
 163:	31 c0                	xor    %eax,%eax
 165:	8d 76 00             	lea    0x0(%esi),%esi
 168:	40                   	inc    %eax
 169:	89 c1                	mov    %eax,%ecx
 16b:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 16f:	75 f7                	jne    168 <strlen+0x10>
 171:	89 c8                	mov    %ecx,%eax
 173:	5d                   	pop    %ebp
 174:	c3                   	ret    
 175:	8d 76 00             	lea    0x0(%esi),%esi
 178:	31 c9                	xor    %ecx,%ecx
 17a:	89 c8                	mov    %ecx,%eax
 17c:	5d                   	pop    %ebp
 17d:	c3                   	ret    
 17e:	66 90                	xchg   %ax,%ax

00000180 <memset>:
 180:	55                   	push   %ebp
 181:	89 e5                	mov    %esp,%ebp
 183:	57                   	push   %edi
 184:	8b 7d 08             	mov    0x8(%ebp),%edi
 187:	8b 4d 10             	mov    0x10(%ebp),%ecx
 18a:	8b 45 0c             	mov    0xc(%ebp),%eax
 18d:	fc                   	cld    
 18e:	f3 aa                	rep stos %al,%es:(%edi)
 190:	8b 45 08             	mov    0x8(%ebp),%eax
 193:	8b 7d fc             	mov    -0x4(%ebp),%edi
 196:	c9                   	leave  
 197:	c3                   	ret    

00000198 <strchr>:
 198:	55                   	push   %ebp
 199:	89 e5                	mov    %esp,%ebp
 19b:	8b 45 08             	mov    0x8(%ebp),%eax
 19e:	8a 4d 0c             	mov    0xc(%ebp),%cl
 1a1:	8a 10                	mov    (%eax),%dl
 1a3:	84 d2                	test   %dl,%dl
 1a5:	75 0c                	jne    1b3 <strchr+0x1b>
 1a7:	eb 13                	jmp    1bc <strchr+0x24>
 1a9:	8d 76 00             	lea    0x0(%esi),%esi
 1ac:	40                   	inc    %eax
 1ad:	8a 10                	mov    (%eax),%dl
 1af:	84 d2                	test   %dl,%dl
 1b1:	74 09                	je     1bc <strchr+0x24>
 1b3:	38 d1                	cmp    %dl,%cl
 1b5:	75 f5                	jne    1ac <strchr+0x14>
 1b7:	5d                   	pop    %ebp
 1b8:	c3                   	ret    
 1b9:	8d 76 00             	lea    0x0(%esi),%esi
 1bc:	31 c0                	xor    %eax,%eax
 1be:	5d                   	pop    %ebp
 1bf:	c3                   	ret    

000001c0 <gets>:
 1c0:	55                   	push   %ebp
 1c1:	89 e5                	mov    %esp,%ebp
 1c3:	57                   	push   %edi
 1c4:	56                   	push   %esi
 1c5:	53                   	push   %ebx
 1c6:	83 ec 1c             	sub    $0x1c,%esp
 1c9:	31 db                	xor    %ebx,%ebx
 1cb:	8d 75 e7             	lea    -0x19(%ebp),%esi
 1ce:	eb 24                	jmp    1f4 <gets+0x34>
 1d0:	50                   	push   %eax
 1d1:	6a 01                	push   $0x1
 1d3:	56                   	push   %esi
 1d4:	6a 00                	push   $0x0
 1d6:	e8 f4 00 00 00       	call   2cf <read>
 1db:	83 c4 10             	add    $0x10,%esp
 1de:	85 c0                	test   %eax,%eax
 1e0:	7e 1a                	jle    1fc <gets+0x3c>
 1e2:	8a 45 e7             	mov    -0x19(%ebp),%al
 1e5:	8b 55 08             	mov    0x8(%ebp),%edx
 1e8:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
 1ec:	3c 0a                	cmp    $0xa,%al
 1ee:	74 0e                	je     1fe <gets+0x3e>
 1f0:	3c 0d                	cmp    $0xd,%al
 1f2:	74 0a                	je     1fe <gets+0x3e>
 1f4:	89 df                	mov    %ebx,%edi
 1f6:	43                   	inc    %ebx
 1f7:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1fa:	7c d4                	jl     1d0 <gets+0x10>
 1fc:	89 fb                	mov    %edi,%ebx
 1fe:	8b 45 08             	mov    0x8(%ebp),%eax
 201:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
 205:	8d 65 f4             	lea    -0xc(%ebp),%esp
 208:	5b                   	pop    %ebx
 209:	5e                   	pop    %esi
 20a:	5f                   	pop    %edi
 20b:	5d                   	pop    %ebp
 20c:	c3                   	ret    
 20d:	8d 76 00             	lea    0x0(%esi),%esi

00000210 <stat>:
 210:	55                   	push   %ebp
 211:	89 e5                	mov    %esp,%ebp
 213:	56                   	push   %esi
 214:	53                   	push   %ebx
 215:	83 ec 08             	sub    $0x8,%esp
 218:	6a 00                	push   $0x0
 21a:	ff 75 08             	pushl  0x8(%ebp)
 21d:	e8 d5 00 00 00       	call   2f7 <open>
 222:	83 c4 10             	add    $0x10,%esp
 225:	85 c0                	test   %eax,%eax
 227:	78 27                	js     250 <stat+0x40>
 229:	89 c3                	mov    %eax,%ebx
 22b:	83 ec 08             	sub    $0x8,%esp
 22e:	ff 75 0c             	pushl  0xc(%ebp)
 231:	50                   	push   %eax
 232:	e8 d8 00 00 00       	call   30f <fstat>
 237:	89 c6                	mov    %eax,%esi
 239:	89 1c 24             	mov    %ebx,(%esp)
 23c:	e8 9e 00 00 00       	call   2df <close>
 241:	83 c4 10             	add    $0x10,%esp
 244:	89 f0                	mov    %esi,%eax
 246:	8d 65 f8             	lea    -0x8(%ebp),%esp
 249:	5b                   	pop    %ebx
 24a:	5e                   	pop    %esi
 24b:	5d                   	pop    %ebp
 24c:	c3                   	ret    
 24d:	8d 76 00             	lea    0x0(%esi),%esi
 250:	be ff ff ff ff       	mov    $0xffffffff,%esi
 255:	eb ed                	jmp    244 <stat+0x34>
 257:	90                   	nop

00000258 <atoi>:
 258:	55                   	push   %ebp
 259:	89 e5                	mov    %esp,%ebp
 25b:	53                   	push   %ebx
 25c:	8b 4d 08             	mov    0x8(%ebp),%ecx
 25f:	0f be 01             	movsbl (%ecx),%eax
 262:	8d 50 d0             	lea    -0x30(%eax),%edx
 265:	80 fa 09             	cmp    $0x9,%dl
 268:	ba 00 00 00 00       	mov    $0x0,%edx
 26d:	77 16                	ja     285 <atoi+0x2d>
 26f:	90                   	nop
 270:	41                   	inc    %ecx
 271:	8d 14 92             	lea    (%edx,%edx,4),%edx
 274:	01 d2                	add    %edx,%edx
 276:	8d 54 02 d0          	lea    -0x30(%edx,%eax,1),%edx
 27a:	0f be 01             	movsbl (%ecx),%eax
 27d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 280:	80 fb 09             	cmp    $0x9,%bl
 283:	76 eb                	jbe    270 <atoi+0x18>
 285:	89 d0                	mov    %edx,%eax
 287:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 28a:	c9                   	leave  
 28b:	c3                   	ret    

0000028c <memmove>:
 28c:	55                   	push   %ebp
 28d:	89 e5                	mov    %esp,%ebp
 28f:	57                   	push   %edi
 290:	56                   	push   %esi
 291:	8b 55 08             	mov    0x8(%ebp),%edx
 294:	8b 75 0c             	mov    0xc(%ebp),%esi
 297:	8b 45 10             	mov    0x10(%ebp),%eax
 29a:	85 c0                	test   %eax,%eax
 29c:	7e 0b                	jle    2a9 <memmove+0x1d>
 29e:	01 d0                	add    %edx,%eax
 2a0:	89 d7                	mov    %edx,%edi
 2a2:	66 90                	xchg   %ax,%ax
 2a4:	a4                   	movsb  %ds:(%esi),%es:(%edi)
 2a5:	39 f8                	cmp    %edi,%eax
 2a7:	75 fb                	jne    2a4 <memmove+0x18>
 2a9:	89 d0                	mov    %edx,%eax
 2ab:	5e                   	pop    %esi
 2ac:	5f                   	pop    %edi
 2ad:	5d                   	pop    %ebp
 2ae:	c3                   	ret    

000002af <fork>:
 2af:	b8 01 00 00 00       	mov    $0x1,%eax
 2b4:	cd 40                	int    $0x40
 2b6:	c3                   	ret    

000002b7 <exit>:
 2b7:	b8 02 00 00 00       	mov    $0x2,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <wait>:
 2bf:	b8 03 00 00 00       	mov    $0x3,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <pipe>:
 2c7:	b8 04 00 00 00       	mov    $0x4,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <read>:
 2cf:	b8 05 00 00 00       	mov    $0x5,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <write>:
 2d7:	b8 10 00 00 00       	mov    $0x10,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret    

000002df <close>:
 2df:	b8 15 00 00 00       	mov    $0x15,%eax
 2e4:	cd 40                	int    $0x40
 2e6:	c3                   	ret    

000002e7 <kill>:
 2e7:	b8 06 00 00 00       	mov    $0x6,%eax
 2ec:	cd 40                	int    $0x40
 2ee:	c3                   	ret    

000002ef <exec>:
 2ef:	b8 07 00 00 00       	mov    $0x7,%eax
 2f4:	cd 40                	int    $0x40
 2f6:	c3                   	ret    

000002f7 <open>:
 2f7:	b8 0f 00 00 00       	mov    $0xf,%eax
 2fc:	cd 40                	int    $0x40
 2fe:	c3                   	ret    

000002ff <mknod>:
 2ff:	b8 11 00 00 00       	mov    $0x11,%eax
 304:	cd 40                	int    $0x40
 306:	c3                   	ret    

00000307 <unlink>:
 307:	b8 12 00 00 00       	mov    $0x12,%eax
 30c:	cd 40                	int    $0x40
 30e:	c3                   	ret    

0000030f <fstat>:
 30f:	b8 08 00 00 00       	mov    $0x8,%eax
 314:	cd 40                	int    $0x40
 316:	c3                   	ret    

00000317 <link>:
 317:	b8 13 00 00 00       	mov    $0x13,%eax
 31c:	cd 40                	int    $0x40
 31e:	c3                   	ret    

0000031f <mkdir>:
 31f:	b8 14 00 00 00       	mov    $0x14,%eax
 324:	cd 40                	int    $0x40
 326:	c3                   	ret    

00000327 <chdir>:
 327:	b8 09 00 00 00       	mov    $0x9,%eax
 32c:	cd 40                	int    $0x40
 32e:	c3                   	ret    

0000032f <dup>:
 32f:	b8 0a 00 00 00       	mov    $0xa,%eax
 334:	cd 40                	int    $0x40
 336:	c3                   	ret    

00000337 <getpid>:
 337:	b8 0b 00 00 00       	mov    $0xb,%eax
 33c:	cd 40                	int    $0x40
 33e:	c3                   	ret    

0000033f <sbrk>:
 33f:	b8 0c 00 00 00       	mov    $0xc,%eax
 344:	cd 40                	int    $0x40
 346:	c3                   	ret    

00000347 <sleep>:
 347:	b8 0d 00 00 00       	mov    $0xd,%eax
 34c:	cd 40                	int    $0x40
 34e:	c3                   	ret    

0000034f <uptime>:
 34f:	b8 0e 00 00 00       	mov    $0xe,%eax
 354:	cd 40                	int    $0x40
 356:	c3                   	ret    

00000357 <mprotect>:
 357:	b8 16 00 00 00       	mov    $0x16,%eax
 35c:	cd 40                	int    $0x40
 35e:	c3                   	ret    

0000035f <munprotect>:
 35f:	b8 17 00 00 00       	mov    $0x17,%eax
 364:	cd 40                	int    $0x40
 366:	c3                   	ret    

00000367 <set_priority>:
 367:	b8 18 00 00 00       	mov    $0x18,%eax
 36c:	cd 40                	int    $0x40
 36e:	c3                   	ret    
 36f:	90                   	nop

00000370 <printint>:
 370:	55                   	push   %ebp
 371:	89 e5                	mov    %esp,%ebp
 373:	57                   	push   %edi
 374:	56                   	push   %esi
 375:	53                   	push   %ebx
 376:	83 ec 3c             	sub    $0x3c,%esp
 379:	89 45 c0             	mov    %eax,-0x40(%ebp)
 37c:	89 cb                	mov    %ecx,%ebx
 37e:	8b 4d 08             	mov    0x8(%ebp),%ecx
 381:	85 c9                	test   %ecx,%ecx
 383:	74 04                	je     389 <printint+0x19>
 385:	85 d2                	test   %edx,%edx
 387:	78 6b                	js     3f4 <printint+0x84>
 389:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 38c:	c7 45 08 00 00 00 00 	movl   $0x0,0x8(%ebp)
 393:	31 c9                	xor    %ecx,%ecx
 395:	8d 75 d7             	lea    -0x29(%ebp),%esi
 398:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 39b:	31 d2                	xor    %edx,%edx
 39d:	f7 f3                	div    %ebx
 39f:	89 cf                	mov    %ecx,%edi
 3a1:	8d 49 01             	lea    0x1(%ecx),%ecx
 3a4:	8a 92 78 07 00 00    	mov    0x778(%edx),%dl
 3aa:	88 54 3e 01          	mov    %dl,0x1(%esi,%edi,1)
 3ae:	8b 55 c4             	mov    -0x3c(%ebp),%edx
 3b1:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 3b4:	39 da                	cmp    %ebx,%edx
 3b6:	73 e0                	jae    398 <printint+0x28>
 3b8:	8b 55 08             	mov    0x8(%ebp),%edx
 3bb:	85 d2                	test   %edx,%edx
 3bd:	74 07                	je     3c6 <printint+0x56>
 3bf:	c6 44 0d d8 2d       	movb   $0x2d,-0x28(%ebp,%ecx,1)
 3c4:	89 cf                	mov    %ecx,%edi
 3c6:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 3c9:	8d 7c 3d d8          	lea    -0x28(%ebp,%edi,1),%edi
 3cd:	8d 76 00             	lea    0x0(%esi),%esi
 3d0:	8a 07                	mov    (%edi),%al
 3d2:	88 45 d7             	mov    %al,-0x29(%ebp)
 3d5:	50                   	push   %eax
 3d6:	6a 01                	push   $0x1
 3d8:	56                   	push   %esi
 3d9:	ff 75 c0             	pushl  -0x40(%ebp)
 3dc:	e8 f6 fe ff ff       	call   2d7 <write>
 3e1:	89 f8                	mov    %edi,%eax
 3e3:	4f                   	dec    %edi
 3e4:	83 c4 10             	add    $0x10,%esp
 3e7:	39 d8                	cmp    %ebx,%eax
 3e9:	75 e5                	jne    3d0 <printint+0x60>
 3eb:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3ee:	5b                   	pop    %ebx
 3ef:	5e                   	pop    %esi
 3f0:	5f                   	pop    %edi
 3f1:	5d                   	pop    %ebp
 3f2:	c3                   	ret    
 3f3:	90                   	nop
 3f4:	f7 da                	neg    %edx
 3f6:	89 55 c4             	mov    %edx,-0x3c(%ebp)
 3f9:	eb 98                	jmp    393 <printint+0x23>
 3fb:	90                   	nop

000003fc <printf>:
 3fc:	55                   	push   %ebp
 3fd:	89 e5                	mov    %esp,%ebp
 3ff:	57                   	push   %edi
 400:	56                   	push   %esi
 401:	53                   	push   %ebx
 402:	83 ec 2c             	sub    $0x2c,%esp
 405:	8b 75 08             	mov    0x8(%ebp),%esi
 408:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 40b:	8a 13                	mov    (%ebx),%dl
 40d:	84 d2                	test   %dl,%dl
 40f:	74 5c                	je     46d <printf+0x71>
 411:	43                   	inc    %ebx
 412:	8d 45 10             	lea    0x10(%ebp),%eax
 415:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 418:	31 ff                	xor    %edi,%edi
 41a:	eb 20                	jmp    43c <printf+0x40>
 41c:	83 f8 25             	cmp    $0x25,%eax
 41f:	74 3f                	je     460 <printf+0x64>
 421:	88 55 e7             	mov    %dl,-0x19(%ebp)
 424:	50                   	push   %eax
 425:	6a 01                	push   $0x1
 427:	8d 45 e7             	lea    -0x19(%ebp),%eax
 42a:	50                   	push   %eax
 42b:	56                   	push   %esi
 42c:	e8 a6 fe ff ff       	call   2d7 <write>
 431:	83 c4 10             	add    $0x10,%esp
 434:	43                   	inc    %ebx
 435:	8a 53 ff             	mov    -0x1(%ebx),%dl
 438:	84 d2                	test   %dl,%dl
 43a:	74 31                	je     46d <printf+0x71>
 43c:	0f b6 c2             	movzbl %dl,%eax
 43f:	85 ff                	test   %edi,%edi
 441:	74 d9                	je     41c <printf+0x20>
 443:	83 ff 25             	cmp    $0x25,%edi
 446:	75 ec                	jne    434 <printf+0x38>
 448:	83 f8 25             	cmp    $0x25,%eax
 44b:	0f 84 03 01 00 00    	je     554 <printf+0x158>
 451:	83 e8 63             	sub    $0x63,%eax
 454:	83 f8 15             	cmp    $0x15,%eax
 457:	77 1f                	ja     478 <printf+0x7c>
 459:	ff 24 85 20 07 00 00 	jmp    *0x720(,%eax,4)
 460:	bf 25 00 00 00       	mov    $0x25,%edi
 465:	43                   	inc    %ebx
 466:	8a 53 ff             	mov    -0x1(%ebx),%dl
 469:	84 d2                	test   %dl,%dl
 46b:	75 cf                	jne    43c <printf+0x40>
 46d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 470:	5b                   	pop    %ebx
 471:	5e                   	pop    %esi
 472:	5f                   	pop    %edi
 473:	5d                   	pop    %ebp
 474:	c3                   	ret    
 475:	8d 76 00             	lea    0x0(%esi),%esi
 478:	88 55 d0             	mov    %dl,-0x30(%ebp)
 47b:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 47f:	50                   	push   %eax
 480:	6a 01                	push   $0x1
 482:	8d 7d e7             	lea    -0x19(%ebp),%edi
 485:	57                   	push   %edi
 486:	56                   	push   %esi
 487:	e8 4b fe ff ff       	call   2d7 <write>
 48c:	8a 55 d0             	mov    -0x30(%ebp),%dl
 48f:	88 55 e7             	mov    %dl,-0x19(%ebp)
 492:	83 c4 0c             	add    $0xc,%esp
 495:	6a 01                	push   $0x1
 497:	57                   	push   %edi
 498:	56                   	push   %esi
 499:	e8 39 fe ff ff       	call   2d7 <write>
 49e:	83 c4 10             	add    $0x10,%esp
 4a1:	31 ff                	xor    %edi,%edi
 4a3:	eb 8f                	jmp    434 <printf+0x38>
 4a5:	8d 76 00             	lea    0x0(%esi),%esi
 4a8:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4ab:	8b 17                	mov    (%edi),%edx
 4ad:	83 ec 0c             	sub    $0xc,%esp
 4b0:	6a 00                	push   $0x0
 4b2:	b9 10 00 00 00       	mov    $0x10,%ecx
 4b7:	89 f0                	mov    %esi,%eax
 4b9:	e8 b2 fe ff ff       	call   370 <printint>
 4be:	83 c7 04             	add    $0x4,%edi
 4c1:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4c4:	83 c4 10             	add    $0x10,%esp
 4c7:	31 ff                	xor    %edi,%edi
 4c9:	e9 66 ff ff ff       	jmp    434 <printf+0x38>
 4ce:	66 90                	xchg   %ax,%ax
 4d0:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 4d3:	8b 10                	mov    (%eax),%edx
 4d5:	83 c0 04             	add    $0x4,%eax
 4d8:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4db:	85 d2                	test   %edx,%edx
 4dd:	0f 84 81 00 00 00    	je     564 <printf+0x168>
 4e3:	8a 02                	mov    (%edx),%al
 4e5:	84 c0                	test   %al,%al
 4e7:	0f 84 80 00 00 00    	je     56d <printf+0x171>
 4ed:	8d 7d e7             	lea    -0x19(%ebp),%edi
 4f0:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 4f3:	89 d3                	mov    %edx,%ebx
 4f5:	8d 76 00             	lea    0x0(%esi),%esi
 4f8:	88 45 e7             	mov    %al,-0x19(%ebp)
 4fb:	50                   	push   %eax
 4fc:	6a 01                	push   $0x1
 4fe:	57                   	push   %edi
 4ff:	56                   	push   %esi
 500:	e8 d2 fd ff ff       	call   2d7 <write>
 505:	43                   	inc    %ebx
 506:	8a 03                	mov    (%ebx),%al
 508:	83 c4 10             	add    $0x10,%esp
 50b:	84 c0                	test   %al,%al
 50d:	75 e9                	jne    4f8 <printf+0xfc>
 50f:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 512:	31 ff                	xor    %edi,%edi
 514:	e9 1b ff ff ff       	jmp    434 <printf+0x38>
 519:	8d 76 00             	lea    0x0(%esi),%esi
 51c:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 51f:	8b 17                	mov    (%edi),%edx
 521:	83 ec 0c             	sub    $0xc,%esp
 524:	6a 01                	push   $0x1
 526:	b9 0a 00 00 00       	mov    $0xa,%ecx
 52b:	eb 8a                	jmp    4b7 <printf+0xbb>
 52d:	8d 76 00             	lea    0x0(%esi),%esi
 530:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 533:	8b 00                	mov    (%eax),%eax
 535:	88 45 e7             	mov    %al,-0x19(%ebp)
 538:	51                   	push   %ecx
 539:	6a 01                	push   $0x1
 53b:	8d 7d e7             	lea    -0x19(%ebp),%edi
 53e:	57                   	push   %edi
 53f:	56                   	push   %esi
 540:	e8 92 fd ff ff       	call   2d7 <write>
 545:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
 549:	83 c4 10             	add    $0x10,%esp
 54c:	31 ff                	xor    %edi,%edi
 54e:	e9 e1 fe ff ff       	jmp    434 <printf+0x38>
 553:	90                   	nop
 554:	88 55 e7             	mov    %dl,-0x19(%ebp)
 557:	52                   	push   %edx
 558:	6a 01                	push   $0x1
 55a:	8d 7d e7             	lea    -0x19(%ebp),%edi
 55d:	e9 35 ff ff ff       	jmp    497 <printf+0x9b>
 562:	66 90                	xchg   %ax,%ax
 564:	b0 28                	mov    $0x28,%al
 566:	ba 18 07 00 00       	mov    $0x718,%edx
 56b:	eb 80                	jmp    4ed <printf+0xf1>
 56d:	31 ff                	xor    %edi,%edi
 56f:	e9 c0 fe ff ff       	jmp    434 <printf+0x38>

00000574 <free>:
 574:	55                   	push   %ebp
 575:	89 e5                	mov    %esp,%ebp
 577:	57                   	push   %edi
 578:	56                   	push   %esi
 579:	53                   	push   %ebx
 57a:	8b 5d 08             	mov    0x8(%ebp),%ebx
 57d:	8d 4b f8             	lea    -0x8(%ebx),%ecx
 580:	a1 a0 09 00 00       	mov    0x9a0,%eax
 585:	8d 76 00             	lea    0x0(%esi),%esi
 588:	89 c2                	mov    %eax,%edx
 58a:	8b 00                	mov    (%eax),%eax
 58c:	39 ca                	cmp    %ecx,%edx
 58e:	73 2c                	jae    5bc <free+0x48>
 590:	39 c1                	cmp    %eax,%ecx
 592:	72 04                	jb     598 <free+0x24>
 594:	39 c2                	cmp    %eax,%edx
 596:	72 f0                	jb     588 <free+0x14>
 598:	8b 73 fc             	mov    -0x4(%ebx),%esi
 59b:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 59e:	39 f8                	cmp    %edi,%eax
 5a0:	74 2c                	je     5ce <free+0x5a>
 5a2:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5a5:	8b 42 04             	mov    0x4(%edx),%eax
 5a8:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5ab:	39 f1                	cmp    %esi,%ecx
 5ad:	74 36                	je     5e5 <free+0x71>
 5af:	89 0a                	mov    %ecx,(%edx)
 5b1:	89 15 a0 09 00 00    	mov    %edx,0x9a0
 5b7:	5b                   	pop    %ebx
 5b8:	5e                   	pop    %esi
 5b9:	5f                   	pop    %edi
 5ba:	5d                   	pop    %ebp
 5bb:	c3                   	ret    
 5bc:	39 c2                	cmp    %eax,%edx
 5be:	72 c8                	jb     588 <free+0x14>
 5c0:	39 c1                	cmp    %eax,%ecx
 5c2:	73 c4                	jae    588 <free+0x14>
 5c4:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5c7:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 5ca:	39 f8                	cmp    %edi,%eax
 5cc:	75 d4                	jne    5a2 <free+0x2e>
 5ce:	03 70 04             	add    0x4(%eax),%esi
 5d1:	89 73 fc             	mov    %esi,-0x4(%ebx)
 5d4:	8b 02                	mov    (%edx),%eax
 5d6:	8b 00                	mov    (%eax),%eax
 5d8:	89 43 f8             	mov    %eax,-0x8(%ebx)
 5db:	8b 42 04             	mov    0x4(%edx),%eax
 5de:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 5e1:	39 f1                	cmp    %esi,%ecx
 5e3:	75 ca                	jne    5af <free+0x3b>
 5e5:	03 43 fc             	add    -0x4(%ebx),%eax
 5e8:	89 42 04             	mov    %eax,0x4(%edx)
 5eb:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 5ee:	89 0a                	mov    %ecx,(%edx)
 5f0:	89 15 a0 09 00 00    	mov    %edx,0x9a0
 5f6:	5b                   	pop    %ebx
 5f7:	5e                   	pop    %esi
 5f8:	5f                   	pop    %edi
 5f9:	5d                   	pop    %ebp
 5fa:	c3                   	ret    
 5fb:	90                   	nop

000005fc <malloc>:
 5fc:	55                   	push   %ebp
 5fd:	89 e5                	mov    %esp,%ebp
 5ff:	57                   	push   %edi
 600:	56                   	push   %esi
 601:	53                   	push   %ebx
 602:	83 ec 0c             	sub    $0xc,%esp
 605:	8b 45 08             	mov    0x8(%ebp),%eax
 608:	8d 78 07             	lea    0x7(%eax),%edi
 60b:	c1 ef 03             	shr    $0x3,%edi
 60e:	47                   	inc    %edi
 60f:	8b 15 a0 09 00 00    	mov    0x9a0,%edx
 615:	85 d2                	test   %edx,%edx
 617:	0f 84 93 00 00 00    	je     6b0 <malloc+0xb4>
 61d:	8b 02                	mov    (%edx),%eax
 61f:	8b 48 04             	mov    0x4(%eax),%ecx
 622:	39 f9                	cmp    %edi,%ecx
 624:	73 62                	jae    688 <malloc+0x8c>
 626:	89 fb                	mov    %edi,%ebx
 628:	81 ff 00 10 00 00    	cmp    $0x1000,%edi
 62e:	72 78                	jb     6a8 <malloc+0xac>
 630:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 637:	eb 0e                	jmp    647 <malloc+0x4b>
 639:	8d 76 00             	lea    0x0(%esi),%esi
 63c:	89 c2                	mov    %eax,%edx
 63e:	8b 02                	mov    (%edx),%eax
 640:	8b 48 04             	mov    0x4(%eax),%ecx
 643:	39 f9                	cmp    %edi,%ecx
 645:	73 41                	jae    688 <malloc+0x8c>
 647:	39 05 a0 09 00 00    	cmp    %eax,0x9a0
 64d:	75 ed                	jne    63c <malloc+0x40>
 64f:	83 ec 0c             	sub    $0xc,%esp
 652:	56                   	push   %esi
 653:	e8 e7 fc ff ff       	call   33f <sbrk>
 658:	83 c4 10             	add    $0x10,%esp
 65b:	83 f8 ff             	cmp    $0xffffffff,%eax
 65e:	74 1c                	je     67c <malloc+0x80>
 660:	89 58 04             	mov    %ebx,0x4(%eax)
 663:	83 ec 0c             	sub    $0xc,%esp
 666:	83 c0 08             	add    $0x8,%eax
 669:	50                   	push   %eax
 66a:	e8 05 ff ff ff       	call   574 <free>
 66f:	8b 15 a0 09 00 00    	mov    0x9a0,%edx
 675:	83 c4 10             	add    $0x10,%esp
 678:	85 d2                	test   %edx,%edx
 67a:	75 c2                	jne    63e <malloc+0x42>
 67c:	31 c0                	xor    %eax,%eax
 67e:	8d 65 f4             	lea    -0xc(%ebp),%esp
 681:	5b                   	pop    %ebx
 682:	5e                   	pop    %esi
 683:	5f                   	pop    %edi
 684:	5d                   	pop    %ebp
 685:	c3                   	ret    
 686:	66 90                	xchg   %ax,%ax
 688:	39 cf                	cmp    %ecx,%edi
 68a:	74 4c                	je     6d8 <malloc+0xdc>
 68c:	29 f9                	sub    %edi,%ecx
 68e:	89 48 04             	mov    %ecx,0x4(%eax)
 691:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
 694:	89 78 04             	mov    %edi,0x4(%eax)
 697:	89 15 a0 09 00 00    	mov    %edx,0x9a0
 69d:	83 c0 08             	add    $0x8,%eax
 6a0:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6a3:	5b                   	pop    %ebx
 6a4:	5e                   	pop    %esi
 6a5:	5f                   	pop    %edi
 6a6:	5d                   	pop    %ebp
 6a7:	c3                   	ret    
 6a8:	bb 00 10 00 00       	mov    $0x1000,%ebx
 6ad:	eb 81                	jmp    630 <malloc+0x34>
 6af:	90                   	nop
 6b0:	c7 05 a0 09 00 00 a4 	movl   $0x9a4,0x9a0
 6b7:	09 00 00 
 6ba:	c7 05 a4 09 00 00 a4 	movl   $0x9a4,0x9a4
 6c1:	09 00 00 
 6c4:	c7 05 a8 09 00 00 00 	movl   $0x0,0x9a8
 6cb:	00 00 00 
 6ce:	b8 a4 09 00 00       	mov    $0x9a4,%eax
 6d3:	e9 4e ff ff ff       	jmp    626 <malloc+0x2a>
 6d8:	8b 08                	mov    (%eax),%ecx
 6da:	89 0a                	mov    %ecx,(%edx)
 6dc:	eb b9                	jmp    697 <malloc+0x9b>
